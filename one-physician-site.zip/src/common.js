(function(){
  'use strict';
  const C=window.StudyContent;
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tpl=(s,d)=>String(s??'').replace(/\{doctor\}/g,d.name).replace(/\{department\}/g,d.department).replace(/\{title\}/g,d.title);
  const uid=(p='id')=>p+'_'+(crypto.randomUUID?crypto.randomUUID():Date.now()+'_'+Math.random().toString(36).slice(2));
  function download(filename,data,mime='application/json') {const blob=data instanceof Blob?data:new Blob([typeof data==='string'?data:JSON.stringify(data,null,2)],{type:mime}); const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),10000);}
  function notice(msg){let el=document.getElementById('toast');if(!el){el=document.createElement('div');el.id='toast';el.setAttribute('role','status');document.body.append(el);}el.textContent=msg;el.classList.add('visible');clearTimeout(notice.timer);notice.timer=setTimeout(()=>el.classList.remove('visible'),4500);}
  const orders={S1:[['A','avatar'],['B','general']],S2:[['B','avatar'],['A','general']],S3:[['A','general'],['B','avatar']],S4:[['B','general'],['A','avatar']]};
  function scenarios(order='S1'){if(!orders[order])throw Error('未知顺序：'+order);return orders[order].map(([caseId,identity])=>({caseId,identity}));}
  function parseConfig(){const p=new URLSearchParams(location.search),valid=(key,allowed,fallback)=>{const v=p.get(key)||fallback;if(!allowed.includes(v))throw Error('无效配置 '+key);return v;};const pid=p.get('pid')||'PREVIEW';const sid=p.get('sid')||pid+'_session01';if(!/^[A-Za-z0-9_-]{1,80}$/.test(pid)||!/^[A-Za-z0-9_-]{1,100}$/.test(sid))throw Error('编号只可使用字母、数字、下划线和短横线。');return {pid,session_id:sid,order:valid('order',Object.keys(orders),'S1'),directions:[valid('d1',['XY','YX'],'XY'),valid('d2',['XY','YX'],'YX')],mode:valid('mode',['preview','study'],'preview'),study_material_version:C.study_material_version,content_version:C.content_version};}
  function defaultBlock(kind,caseId,direction){const c=C.cases[caseId],d=c.doctor,s=C.design_blocks[kind];if(!s)throw Error('未知素材');const doctorAdvice=direction==='XY'?'Y':'X';let text=s.text_reference?c.advice[doctorAdvice].d3:tpl(s.text||'',d);if(kind==='D4')text=tpl(s.ai_label,d)+'\n'+tpl(s.doctor_label,d);return {id:uid('block'),kind,name:s.name,label:tpl(s.label||s.name,d),position:s.position||'below-doctor',text,collapsed:kind==='D5',original_source:kind};}
  function avatar(d,isAI=false,general=false){
    if(general)return '<span class="avatar platform-avatar" aria-label="平台 AI 图标"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="6" width="16" height="14" rx="5"/><path d="M12 2v4M8 12h.01M16 12h.01M8 16h8"/></svg><b>AI</b></span>';
    // Two abstract silhouettes use the same dimensions, palette and detail level.
    // A doctor's avatar and that doctor's AI avatar always use the same SVG.
    const shape=d.id==='doctor_lin'?'<ellipse cx="20" cy="14" rx="6.3" ry="7.2"/><path d="M6 38c1-10 6-16 14-16s13 6 14 16Z"/>':'<circle cx="20" cy="14" r="7"/><path d="M8 38V32c0-6 5-11 12-11s12 5 12 11v6Z"/>';
    return `<span class="avatar physician-avatar" aria-label="${esc(d.name)}的虚构头像"><svg viewBox="0 0 40 40" aria-hidden="true">${shape}</svg>${isAI?'<b>AI</b>':''}</span>`;
  }
  function caseParagraphs(text,caseId){
    // Layout-only sentence grouping: concatenating all paragraphs reproduces
    // the source text byte-for-byte. No clinical labels or headings are added.
    const sentences=String(text).match(/[^。！？]*[。！？]|[^。！？]+$/gu)||[String(text)];
    if(sentences.length<4)return sentences.map(s=>`<p>${esc(s)}</p>`).join('');
    const cuts=caseId==='A'?[1,2,4]:[1,2,3];
    let start=0;
    return [...cuts,sentences.length].filter((n,i,a)=>n>0&&n<=sentences.length&&a.indexOf(n)===i).map(end=>{const part=sentences.slice(start,end).join('');start=end;return part?`<p>${esc(part)}</p>`:'';}).join('');
  }
  function renderPhone({caseId='A',identity='avatar',direction='XY',phase='both',mode='conflict',blocks=[],consultationEnded=false,participantProposal={}}={}){
    const c=C.cases[caseId];if(!c)throw Error('病例尚未可用');
    if(!['avatar','general'].includes(identity)||!['XY','YX'].includes(direction)||!['conflict','agree','reverse'].includes(mode))throw Error('渲染配置错误');
    const d=c.doctor,id=C.identity_templates[identity],aiKey=direction[0],docKey=mode==='agree'?aiKey:direction[1],prefs=C.ui_preferences||{};
    const aiText=participantProposal.ai_text??c.advice[aiKey].text,docText=participantProposal.doctor_text??c.advice[docKey].text,caseText=participantProposal.case_text??c.case_text;
    const aiTitle=tpl(id.title,d),aiSubtitle=tpl(id.subtitle,d);
    const blockHTML=b=>{
      const attrs=`data-block-id="${esc(b.id)}" data-block-kind="${esc(b.kind)}"`,text=esc(b.text).replace(/\n/g,'<br>');
      if(b.kind==='D5')return '';
      if(b.kind==='D4'){
        const lines=(b.text||'').split('\n');
        return `<nav class="design-block advice-index" ${attrs} aria-label="建议索引"><strong>${esc(b.label||'建议索引')}</strong><button data-jump="ai-message">${esc(lines[0]||'AI 初步建议')}<span aria-hidden="true">›</span></button><button data-jump="doctor-message">${esc(lines[1]||'医生建议')}<span aria-hidden="true">›</span></button></nav>`;
      }
      if(b.kind==='blank-button')return `<div class="design-block blank-block" ${attrs}><button class="btn secondary" data-action="custom-block" data-custom-id="${esc(b.id)}">${esc(b.label)}</button></div>`;
      if(b.kind==='blank-text')return `<div class="design-block blank-block" ${attrs}><p>${text}</p></div>`;
      if(b.kind==='D2')return `<article class="message design-block ai-explanation" ${attrs}><div class="message-head">${avatar(d,true,identity==='general')}<div><h3>${esc(aiTitle)}</h3><p>${esc(aiSubtitle)}</p></div></div><p class="advice-text">${text}</p></article>`;
      if(b.kind==='D3')return `<p class="doctor-explanation" ${attrs}>${text}</p>`;
      if(b.kind==='D3p')return `<aside class="design-block platform-explanation" ${attrs}><strong>${esc(b.label)}</strong><p>${text}</p></aside>`;
      if(b.kind==='D1')return `<aside class="design-block platform-note" ${attrs}><p>${text}</p><button class="inline-link" data-action="contact-doctor">${esc(b.label||'联系医生')} <span aria-hidden="true">›</span></button></aside>`;
      return `<aside class="design-block platform-note ${b.kind==='D6'?'service-rule':''}" ${attrs}><p>${text}</p></aside>`;
    };
    const at=p=>blocks.filter(b=>b.position===p&&b.kind!=='D5').map(blockHTML).join('');
    const aiBody=`<p class="greeting">${esc(tpl(id.greeting,d))}</p><p class="advice-text" data-advice="ai">${esc(aiText)}</p>${at('in-ai')}<p class="review-note">${esc(tpl(C.shared_ui.review,d))}</p>`;
    const fold=blocks.find(b=>b.kind==='D5');
    // D5 collapse scope = greeting + advice + review note, including any
    // participant-inserted in-AI blocks. Avatar/title/subtitle/technical stay visible.
    const ai=`${at('above-ai')}<article class="message ai-message" id="ai-message" tabindex="-1"><div class="message-head">${avatar(d,true,identity==='general')}<div><h3>${esc(aiTitle)}</h3><p>${esc(aiSubtitle)}</p></div><time>${mode==='reverse'?'14:36':'10:02'}</time></div><p class="technical">${esc(C.shared_ui.technical)}</p>${fold?`<details class="ai-collapse" data-ai-collapse ${fold.collapsed?'':'open'}><summary data-action="toggle-ai"><span class="fold-closed">${esc(fold.text||'AI 初步建议')} ${esc(fold.label||'展开')}</span><span class="fold-open">${esc((fold.text||'AI 初步建议').replace('（已收起）',''))} 收起</span></summary>${aiBody}</details>`:aiBody}</article>`;
    const doctor=`<article class="message doctor-message" id="doctor-message" tabindex="-1"><div class="message-head">${avatar(d)}<div><h3>${esc(d.name)}</h3><p>${esc(d.department)} · ${esc(d.title)}</p></div><time>${mode==='reverse'?'10:02':'14:36'}</time></div><p class="doctor-salutation">${esc(C.shared_ui.doctor_prefix)}</p><p class="advice-text" data-advice="doctor">${esc(docText)}</p>${at('in-doctor')}<p class="signature">${esc(tpl(C.shared_ui.doctor_signature,d))}</p></article>${at('below-doctor')}`;
    const seen=participantProposal.timeline_text??tpl(mode==='reverse'?C.supplements.reverse_fact:mode==='agree'?C.supplements.agreement_fact:C.shared_ui.reviewed,d);
    // The timeline is platform/system material, outside both speaker cards.
    const system=`<p class="channel-rule system-line" data-system-line tabindex="-1">${esc(seen)}</p>`;
    const actions=phase==='ai'?'':C.shared_ui.actions.map(a=>{
      const disabled=consultationEnded&&!['basis','source'].includes(a.id);
      return `<button class="action-button" data-action="${a.id}" ${disabled?'disabled':''}>${esc(a.label)}<span aria-hidden="true">›</span></button>`;
    }).join('');
    const conversation=phase==='ai'?ai:mode==='reverse'?doctor+at('between')+system+ai:ai+at('between')+system+doctor;
    const reviewFont=Number(prefs.review_font_px)===14?14:12;
    const viewportHeight=Number(prefs.desktop_phone_height);
    const fixed=Number.isFinite(viewportHeight)&&viewportHeight>=320;
    const phoneStyle=`--review-font:${reviewFont}px;${fixed?'--phone-height:'+Math.min(viewportHeight,1200)+'px;':''}`;
    const actionHeading=prefs.action_heading?`<h3 class="actions-heading">${esc(prefs.action_heading)}</h3>`:'';
    return `<section class="study-phone${fixed?' phone-viewport':''}" style="${phoneStyle}" data-case="${caseId}" data-identity="${identity}" data-direction="${direction}" data-mode="${mode}"><header class="phone-top"><span class="brand-mark">＋</span><strong>${esc(C.platform)}</strong><span class="demo-label">模拟问诊</span></header><div class="phone-body"><section class="case-card"><div class="section-eyebrow">${esc(C.shared_ui.case_heading)}</div><h2>${esc(c.title)}</h2>${caseParagraphs(caseText,caseId)}</section><section class="doctor-profile">${avatar(d)}<div><span class="section-eyebrow">${esc(C.shared_ui.doctor_heading)}</span><h3>${esc(d.name)} <small>${esc(d.title)}</small></h3><p>${esc(d.hospital)} · ${esc(d.department)}</p></div></section><div class="channel-rule">同一线上问诊 · ${phase==='ai'?'初步回复':'沟通记录'}</div>${conversation}${consultationEnded?'<p class="ended-note">本次模拟咨询已结束 · 历史记录仍可查看</p>':''}${phase==='ai'?'':`<section class="actions" aria-label="你可以进行的操作">${actionHeading}${actions}${at('actions')}</section>`}<p class="phone-footer">以上为虚构研究情境，请围绕材料进行体验。</p></div></section>`;
  }
  function phonesIn(root){return root?.matches?.('.study-phone')?[root]:Array.from(root?.querySelectorAll?.('.study-phone')||[]);}
  function usesInternalScroll(phone){
    if(!phone||typeof getComputedStyle!=='function')return false;
    const style=getComputedStyle(phone);
    return /^(auto|scroll)$/.test(style.overflowY)&&phone.scrollHeight>phone.clientHeight;
  }
  function motionBehavior(requested='smooth'){
    return typeof window.matchMedia==='function'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':requested;
  }
  function scrollPhoneTarget(phone,target,{behavior='smooth',focus=false}={}){
    if(!phone||!target)return false;
    const header=phone.querySelector('.phone-top');
    const sticky=header&&typeof getComputedStyle==='function'&&getComputedStyle(header).position==='sticky';
    const offset=(sticky?header.getBoundingClientRect().height:0)+16;
    if(usesInternalScroll(phone)){
      const top=phone.scrollTop+target.getBoundingClientRect().top-phone.getBoundingClientRect().top-offset;
      phone.scrollTo({top:Math.max(0,top),behavior:motionBehavior(behavior)});
    }else if(typeof window.scrollTo==='function'){
      window.scrollTo({top:Math.max(0,(window.scrollY||0)+target.getBoundingClientRect().top-16),behavior:motionBehavior(behavior)});
    }
    if(focus&&target.focus)target.focus({preventScroll:true});
    return true;
  }
  function scrollToSystem(root=document,{behavior='smooth'}={}){
    const phone=phonesIn(root)[0];
    return scrollPhoneTarget(phone,phone?.querySelector('[data-system-line]'),{behavior,focus:true});
  }
  function resetPhoneScroll(root=document){
    phonesIn(root).forEach(phone=>{phone.scrollTop=0;});
    if(typeof window.scrollTo==='function')window.scrollTo({top:0,behavior:'auto'});
  }
  const boundRoots=new WeakSet(),outlineTimers=new WeakMap();
  function bindPhoneInteractions(root=document){
    if(!root||boundRoots.has(root)||!root.addEventListener)return;
    boundRoots.add(root);
    root.addEventListener('click',event=>{
      const trigger=event.target?.closest?.('[data-jump]');
      if(!trigger||event.__studyPhoneHandled)return;
      const phone=trigger.closest('.study-phone'),targetId=trigger.getAttribute('data-jump');
      if(!phone||!['ai-message','doctor-message'].includes(targetId))return;
      const target=phone.querySelector('[id="'+targetId+'"]');
      if(!target)return;
      event.__studyPhoneHandled=true;event.preventDefault();
      const collapsed=target.querySelector('details[data-ai-collapse]'),expanded=!!collapsed&&!collapsed.open;
      if(expanded)collapsed.open=true;
      const run=()=>{
        scrollPhoneTarget(phone,target,{focus:true});
        target.classList.add('message-jump-outline');
        clearTimeout(outlineTimers.get(target));
        outlineTimers.set(target,setTimeout(()=>target.classList.remove('message-jump-outline'),1500));
        if(typeof CustomEvent==='function')trigger.dispatchEvent(new CustomEvent('study:phone-jump',{bubbles:true,detail:{target:targetId,expanded_ai:expanded}}));
      };
      if(typeof requestAnimationFrame==='function')requestAnimationFrame(run);else run();
    });
  }
  function fullPhoneClone(element){
    if(!element)throw Error('手机预览未准备好。');
    const clone=element.cloneNode(true),originals=[element,...element.querySelectorAll('*')],clones=[clone,...clone.querySelectorAll('*')];
    originals.forEach((el,i)=>{
      const style=getComputedStyle(el);let css='';
      for(const key of style)css+=key+':'+style.getPropertyValue(key)+';';
      clones[i].setAttribute('style',css);
      clones[i].removeAttribute('id');
      clones[i].removeAttribute('tabindex');
    });
    clone.classList.remove('phone-viewport');
    clone.querySelectorAll('.message-jump-outline').forEach(el=>{el.classList.remove('message-jump-outline');el.style.outline='none';});
    // Preserve the visible D5 state; capture all scrolling content without
    // expanding deliberately collapsed advice or clipping at the desktop viewport.
    clone.querySelectorAll('details:not([open])').forEach(el=>Array.from(el.children).filter(x=>x.tagName!=='SUMMARY').forEach(x=>x.remove()));
    const width=Math.ceil(element.getBoundingClientRect().width);
    Object.assign(clone.style,{margin:'0',width:width+'px',maxWidth:'none',height:'auto',maxHeight:'none',overflow:'visible',overflowY:'visible',position:'static',transform:'none'});
    const top=clone.querySelector('.phone-top');if(top)Object.assign(top.style,{position:'static',top:'auto'});
    const holder=document.createElement('div');holder.style.cssText='position:fixed;left:-10000px;top:0;pointer-events:none;';holder.append(clone);document.body.append(holder);
    const height=Math.ceil(Math.max(clone.scrollHeight,clone.getBoundingClientRect().height));holder.remove();
    if(!width||!height)throw Error('预览尺寸不可用，请打开完整方案后重试。');
    return {clone,width,height};
  }
  async function capturePhone(element,filename='设计方案.png',options={}){
    if(document.fonts?.ready)await document.fonts.ready;
    const {clone,width:w,height:h}=fullPhoneClone(element);
    const serialized=new XMLSerializer().serializeToString(clone);
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml">${serialized}</div></foreignObject></svg>`;
    const img=new Image();await new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>reject(Error('图片生成超时，请使用打印视图保存 PDF。')),6000);
      img.onload=()=>{clearTimeout(timeout);resolve();};img.onerror=()=>{clearTimeout(timeout);reject(Error('浏览器无法生成图片，请使用打印视图保存 PDF。'));};
      img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
    });
    const canvas=document.createElement('canvas');canvas.width=w*2;canvas.height=h*2;
    const ctx=canvas.getContext('2d');if(!ctx)throw Error('浏览器不支持图片导出。');
    ctx.scale(2,2);ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0);
    // Some foreignObject implementations report onload but paint only white.
    // The rendered study phone has a colored platform header and text, so an
    // all-white sample is a failed export rather than a usable study record.
    const pixels=ctx.getImageData(0,0,canvas.width,Math.min(canvas.height,200)).data;
    let ink=false;for(let i=0;i<pixels.length;i+=16){if(pixels[i]<240||pixels[i+1]<240||pixels[i+2]<240){ink=true;break;}}
    if(!ink)throw Error('浏览器生成了空白图片，请使用打印视图保存 PDF。');
    const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('未能生成 PNG')),'image/png'));
    if(options.download!==false)download(filename,blob,'image/png');return blob;
  }
  function printPhone(element,filename='设计方案.pdf'){
    const {clone}=fullPhoneClone(element),previous=document.getElementById('study-print-view');
    if(previous)previous.remove();
    const previousTitle=document.title,previousFocus=document.activeElement;
    const overlay=document.createElement('section');overlay.id='study-print-view';overlay.className='study-print-view';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','方案打印预览');
    overlay.innerHTML='<header class="study-print-controls"><h2>方案打印预览</h2><p>在打印窗口选择“存储为 PDF”，保存完整界面。</p><div class="toolbar"><button class="btn primary" data-print-phone>打印／保存 PDF</button><button class="btn" data-close-print>返回工作台</button></div></header><div class="study-print-phone"></div>';
    overlay.querySelector('.study-print-phone').append(clone);
    const close=()=>{overlay.remove();document.body.classList.remove('study-print-active');document.title=previousTitle;previousFocus?.focus?.();};
    overlay.querySelector('[data-close-print]').onclick=close;
    overlay.querySelector('[data-print-phone]').onclick=()=>window.print();
    overlay.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();close();}
      if(event.key==='Tab'){
        const buttons=Array.from(overlay.querySelectorAll('.study-print-controls button')),first=buttons[0],last=buttons[buttons.length-1];
        if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
        else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
      }
    });
    document.body.append(overlay);document.body.classList.add('study-print-active');document.title=filename.replace(/\.pdf$/i,'');
    overlay.querySelector('[data-print-phone]').focus();return overlay;
  }
  window.Study={esc,tpl,uid,download,notice,parseConfig,scenarios,renderPhone,defaultBlock,bindPhoneInteractions,scrollToSystem,resetPhoneScroll,capturePhone,printPhone};
})();
