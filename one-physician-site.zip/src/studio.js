(function () {
  'use strict';

  var S = window.Study;
  var C = window.StudyContent;
  var app = document.getElementById('app');
  if (!S || !C || !app) return;
  var isDisplay = document.body.dataset.page === 'display';
  document.title = isDisplay ? '界面预览' : '研究者操作';
  var config;
  try { config = S.parseConfig(); } catch (error) { app.innerHTML = '<main class="page-shell panel"><h1>场次链接需要检查</h1><p>' + S.esc(error.message) + '</p></main>'; return; }
  var scenarioList = S.scenarios(config.order);
  var scenarioIndex = scenarioList.findIndex(function (item) { return item.identity === 'avatar'; });
  if (scenarioIndex < 0) scenarioIndex = 0;
  var scenario = scenarioList[scenarioIndex];
  var caseData = C.cases[scenario.caseId];
  var direction = (config.directions || [])[scenarioIndex] || 'XY';
  var storageKey = 'one-physician:studio:' + config.session_id;
  var displayKey = 'one-physician:studio-display:' + config.session_id;
  var commandKey = 'one-physician:studio-command:' + config.session_id;
  var channelName = 'one-physician:studio-channel:' + config.session_id;
  var channel = null;
  var displayWindow = null;
  var state = null;
  var displaySnapshot = null;
  var syncSerial = 0;
  var lastLiveSignal = 0;
  var displayConnected = false;
  var heartbeatTimer = null;
  var heartbeatKey = 'one-physician:studio-heartbeat:';
  var studioInstance = S.uid('studio_window');
  var storageProblem = '';
  var selectedBlock = null;
  var busy = false;
  var seenCommands = new Set();
  var ui = { initiator: 'participant', changeNote: '', clinicalOpen: false };
  var kinds = ['D1', 'D2', 'D3', 'D3p', 'D4', 'D5', 'D6', 'blank-text', 'blank-button'];
  var browseSteps = [['D1'], ['D2'], ['D3', 'D3p'], ['D4'], ['D5'], ['D6']];
  var names = { D1: '平台差异提示', D2: 'AI 的说明', D3: '医生的说明', D3p: '平台展示的医生说明', D4: '建议索引', D5: '折叠的初步建议', D6: '服务规则', 'blank-text': '自拟文字', 'blank-button': '自拟按钮' };
  var positions = { 'above-ai': 'AI 消息上方', 'in-ai': 'AI 消息内', between: '两条消息之间', 'in-doctor': '医生消息内', 'below-doctor': '医生消息下方', actions: '操作区' };
  var initiators = { participant: '参与者提出', researcher_assisted: '研究者辅助措辞', researcher_proposed: '研究者提出替代方案' };
  var clinicalNames = { case_text: '病情描述', ai_text: 'AI 建议正文', doctor_text: '医生建议正文', timeline_text: '时间线系统说明' };
  var now = function () { return new Date().toISOString(); };
  var copy = function (value) { return JSON.parse(JSON.stringify(value)); };
  var E = S.esc;

  function note(message) { S.notice(message); }
  function sameConfig(a, b) {
    return !!a && !!b && ['pid', 'session_id', 'order', 'mode', 'study_material_version', 'content_version'].every(function (key) { return a[key] === b[key]; }) && JSON.stringify(a.directions) === JSON.stringify(b.directions);
  }
  function originalFields() {
    return { case_text: caseData.case_text, ai_text: caseData.advice[direction.charAt(0)].text, doctor_text: caseData.advice[direction.charAt(1)].text, timeline_text: S.tpl(C.shared_ui.reviewed, caseData.doctor) };
  }
  function clinicalReady() {
    var review = C.clinical_review_status || {};
    return review.status === 'approved' && !!review.record_id && scenarioList.every(function (item) {
      var status = C.cases[item.caseId].clinical_review_status;
      return status === 'approved' || (status && status.status === 'approved');
    });
  }
  function initialState() {
    var original = originalFields();
    return {
      schema_version: '1.0', kind: 'studio_design', config: copy(config),
      session_id: config.session_id, pid: config.pid, segment_id: S.uid('studio_segment'),
      study_material_version: config.study_material_version, content_version: config.content_version,
      created_at: now(), updated_at: now(), saved_at: null, studio_revision: 0,
      base: { caseId: scenario.caseId, identity: 'avatar', direction: direction, phase: 'both', mode: 'conflict', scenario_index: scenarioIndex + 1, blocks: [], original_content: original },
      initial_config: { caseId: scenario.caseId, identity: 'avatar', direction: direction, phase: 'both', mode: 'conflict', blocks: [] },
      blocks: [], participant_proposal: { unreviewed: true, label: '参与者内容提议，未作临床审核', fields: {} },
      researcher_notes: '', participant_confirmation: { status: 'pending', confirmed_at: null, confirmed_revision: null, reason: '' },
      materials: { stage: 'self', visible: false, browse_index: -1, viewed: [], material_preview: null },
      history: [], events: [], undo_stack: [], redo_stack: [], save_records: []
    };
  }
  function editSnapshot() {
    return copy({ blocks: state.blocks, participant_proposal: state.participant_proposal, researcher_notes: state.researcher_notes, participant_confirmation: state.participant_confirmation, materials: state.materials });
  }
  function useSnapshot(snapshot) {
    ['blocks', 'participant_proposal', 'researcher_notes', 'participant_confirmation', 'materials'].forEach(function (key) { state[key] = copy(snapshot[key]); });
  }
  function eventRecord(type, target, text, extra) {
    var event = Object.assign({ event_id: S.uid('studio_event'), session_id: config.session_id, segment_id: state.segment_id, pid: config.pid, event_time: now(), sequence_no: state.events.reduce(function (max, e) { return Math.max(max, Number(e.sequence_no) || 0); }, 0) + 1, order: config.order, scenario_index: scenarioIndex + 1, case_id: scenario.caseId, doctor_id: caseData.doctor.id || caseData.doctor.name, identity: 'avatar', direction: direction, phase: 'design', event_type: type, target: target || '', text: text || '', source: 'studio', study_material_version: config.study_material_version, content_version: config.content_version, studio_revision: state.studio_revision, initiator: ui.initiator, modification_note: ui.changeNote, elicitation_context: state.materials.stage === 'self' ? 'participant_self_generated' : 'material_elicited' }, extra || {});
    state.events.push(event);
    if (event.initiator === 'researcher_assisted') event.elicitation_context = 'researcher_assistance';
    if (event.initiator === 'researcher_proposed') event.elicitation_context = 'researcher_proposed_alternative';
    return event;
  }
  function invalidateConfirmation() {
    if (state.participant_confirmation.status === 'confirmed') {
      state.participant_confirmation = { status: 'pending', confirmed_at: null, confirmed_revision: null, reason: '确认后方案有修改，请参与者重新确认。' };
    }
  }
  function change(action, target, mutator, options) {
    options = options || {};
    var before = editSnapshot();
    mutator();
    if (JSON.stringify(before) === JSON.stringify(editSnapshot())) return;
    if (!options.keepConfirmation) invalidateConfirmation();
    state.studio_revision += 1;
    var event = eventRecord(action, target, options.text || '', options.extra);
    var after = editSnapshot();
    state.history.push({ studio_revision: state.studio_revision, event_id: event.event_id, session_id: config.session_id, event_time: event.event_time, action: action, target: target, original_source: options.originalSource || sourceOf(target), initiator: event.initiator, elicitation_context: event.elicitation_context, modification_note: ui.changeNote, before: before, after: after });
    if (options.undoable !== false) {
      state.undo_stack.push(before);
      state.redo_stack = [];
    }
    persist();
    if (options.render === false) renderLive(); else render();
  }
  function sourceOf(id) {
    var block = state.blocks.find(function (b) { return b.id === id; });
    return block ? block.original_source : 'session';
  }
  function readStored(key) {
    try { return localStorage.getItem(key); } catch (error) { storageProblem = '浏览器未允许本地保存，请使用方案保存或 JSON 备份。'; return null; }
  }
  function persist() {
    state.updated_at = now();
    try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch (error) { storageProblem = '本地保存未成功，请立即下载 JSON 备份。'; }
    publish();
  }
  function publicBlock(block) {
    var result = {};
    ['id', 'kind', 'position', 'text', 'label', 'collapsed'].forEach(function (key) { if (block[key] !== undefined) result[key] = block[key]; });
    return result;
  }
  function proposalText() {
    var result = {};
    Object.keys(state.participant_proposal.fields).forEach(function (key) { result[key] = state.participant_proposal.fields[key].proposed; });
    return result;
  }
  function publicState() {
    return { type: 'studio-preview', session_id: config.session_id, serial: ++syncSerial, sent_at: now(), instance_id: studioInstance, base: { caseId: state.base.caseId, identity: 'avatar', direction: state.base.direction, phase: 'both', mode: 'conflict' }, blocks: state.blocks.map(publicBlock), participantProposal: proposalText(), materials: { visible: state.materials.visible, stage: state.materials.stage, viewed: state.materials.viewed.slice(), preview: state.materials.material_preview, paired: state.materials.material_preview === 'D3' || state.materials.material_preview === 'D3p' } };
  }
  function publish() {
    var snapshot = publicState();
    displaySnapshot = snapshot;
    try { localStorage.setItem(displayKey, JSON.stringify(snapshot)); } catch (error) { /* Direct-window synchronization remains available. */ }
    if (channel) channel.postMessage(snapshot);
    if (displayWindow && !displayWindow.closed) displayWindow.postMessage(snapshot, '*');
  }
  function clearPublicState() {
    var message = { type: 'studio-cleared', session_id: config.session_id };
    if (channel) channel.postMessage(message);
    if (displayWindow && !displayWindow.closed) displayWindow.postMessage(message, '*');
  }
  function sendHeartbeat() {
    if (!state) return;
    var message = { type: 'studio-heartbeat', session_id: config.session_id, sent_at: now(), instance_id: studioInstance };
    if (channel) channel.postMessage(message);
    if (displayWindow && !displayWindow.closed) displayWindow.postMessage(message, '*');
    try { localStorage.setItem(heartbeatKey + config.session_id, JSON.stringify(message)); } catch (error) {}
    if (!channel) {
      try { localStorage.setItem(displayKey, JSON.stringify(publicState())); } catch (error) {}
    }
  }
  function pauseDisplay() {
    if (!displayConnected && !displaySnapshot) return;
    displayConnected = false; displaySnapshot = null;
    document.querySelectorAll('.studio-preview-modal,.studio-preview-overlay').forEach(function (el) { el.remove(); });
    render();
  }
  function newBlock(kind) {
    var block = kind === 'blank-text' || kind === 'blank-button' ? { kind: kind, position: 'below-doctor', text: '', label: '', collapsed: false } : copy(S.defaultBlock(kind, scenario.caseId, direction));
    block.id = S.uid('block');
    block.kind = kind;
    block.text = String(block.text || '');
    block.label = String(block.label || '');
    if (!positions[block.position]) block.position = 'below-doctor';
    if (kind === 'blank-text') { block.text = '在这里填写参与者提出的文字'; block.label = '自拟文字'; }
    if (kind === 'blank-button') { block.text = ''; block.label = '在这里填写按钮文字'; block.expected_behavior = ''; }
    block.original_source = kind === 'blank-text' || kind === 'blank-button' ? 'participant_blank' : kind;
    block.original = copy({ kind: block.kind, position: block.position, text: block.text || '', label: block.label || '', collapsed: !!block.collapsed });
    block.created_at = now();
    block.created_by = ui.initiator;
    block.modifications = [];
    return block;
  }
  function recordBlockChange(block, field, before, after) {
    block.modifications.push({ session_id: config.session_id, studio_revision: state.studio_revision + 1, field: field, original_source: block.original_source, initiator: ui.initiator, elicitation_context: state.materials.stage === 'self' ? 'participant_self_generated' : 'material_elicited', before: before, after: after, note: ui.changeNote, modified_at: now() });
  }
  function addBlock(kind) {
    if (state.materials.stage === 'browse') return note('请完成统一素材浏览，再选择并编辑。');
    if (kind.charAt(0) === 'D' && state.materials.stage !== 'edit') return;
    if (kind === 'D5' && state.blocks.some(function (b) { return b.kind === 'D5'; })) return note('当前方案已有折叠模块，可直接编辑。');
    var block = newBlock(kind);
    selectedBlock = block.id;
    change('block_added', block.id, function () { state.blocks.push(block); state.materials.material_preview = null; }, { originalSource: block.original_source });
  }
  function updateBlock(id, field, value) {
    var block = state.blocks.find(function (b) { return b.id === id; });
    if (!block || block[field] === value) return;
    var before = block[field];
    change('block_changed', id, function () {
      recordBlockChange(block, field, before, value); block[field] = value;
      if (field === 'text' && ['D3', 'D3p', 'D4'].indexOf(block.kind) >= 0) {
        block.participant_proposal = value === block.original.text ? null : { original: block.original.text, proposed: value, diff: textDiff(block.original.text, value), label: '参与者内容提议，未作临床审核', unreviewed: true, initiator: ui.initiator, modified_at: now(), studio_revision: state.studio_revision + 1 };
      }
      state.materials.material_preview = null;
    }, { text: field, render: false });
  }
  function undo(redo) {
    var from = redo ? state.redo_stack : state.undo_stack;
    if (!from.length) return;
    var previous = from.pop();
    var before = editSnapshot();
    (redo ? state.undo_stack : state.redo_stack).push(before);
    var workflow = copy(state.materials);
    useSnapshot(previous);
    state.materials = workflow;
    state.materials.material_preview = null;
    invalidateConfirmation();
    state.studio_revision += 1;
    var event = eventRecord(redo ? 'design_redone' : 'design_undone', 'design');
    state.history.push({ studio_revision: state.studio_revision, event_id: event.event_id, session_id: config.session_id, event_time: event.event_time, action: event.event_type, target: 'design', original_source: 'history', initiator: ui.initiator, modification_note: ui.changeNote, before: before, after: editSnapshot() });
    selectedBlock = null;
    persist(); render();
  }
  function textDiff(original, proposed) {
    var start = 0;
    while (start < original.length && start < proposed.length && original[start] === proposed[start]) start++;
    var end = 0;
    while (end < original.length - start && end < proposed.length - start && original[original.length - 1 - end] === proposed[proposed.length - 1 - end]) end++;
    return { common_prefix: original.slice(0, start), removed: original.slice(start, original.length - end), added: proposed.slice(start, proposed.length - end), common_suffix: end ? original.slice(original.length - end) : '' };
  }
  function showMaterials(index) {
    change('material_browsed', browseSteps[index].join('+'), function () {
      state.materials.stage = 'browse'; state.materials.visible = true; state.materials.browse_index = index; state.materials.material_preview = browseSteps[index][0];
      browseSteps[index].forEach(function (kind) { if (state.materials.viewed.indexOf(kind) < 0) state.materials.viewed.push(kind); });
    }, { undoable: false, keepConfirmation: true, originalSource: browseSteps[index].join('+') });
  }
  function renderPhones(snapshot) {
    if (!snapshot) return '<div class="studio-waiting">等待研究者打开设计画面</div>';
    var material = snapshot.materials.visible ? snapshot.materials.preview : null;
    var materialKinds = snapshot.materials.paired && ['D3', 'D3p'].indexOf(material) >= 0 ? ['D3', 'D3p'] : [material];
    return '<div class="studio-phones' + (materialKinds.length > 1 ? ' paired' : '') + '">' + materialKinds.map(function (kind) {
      var blocks = kind ? [S.defaultBlock(kind, snapshot.base.caseId, snapshot.base.direction)] : snapshot.blocks;
      var args = Object.assign({}, snapshot.base, { blocks: blocks, participantProposal: kind ? {} : snapshot.participantProposal });
      return '<section class="studio-preview-item">' + (kind ? '<h2 class="studio-material-title">' + E(names[kind]) + '</h2>' : '') + '<div class="phone-wrap" data-phone-preview="' + (kind ? 'material' : 'design') + '">' + S.renderPhone(args) + '</div></section>';
    }).join('') + '</div>';
  }
  function displayMaterials(snapshot) {
    if (!snapshot || !snapshot.materials.visible) return '';
    var material = snapshot.materials.preview;
    var available = snapshot.materials.stage === 'browse' ? (snapshot.materials.paired ? ['D3', 'D3p'] : [material]) : ['D1', 'D2', 'D3', 'D3p', 'D4', 'D5', 'D6'];
    available = available.filter(function (kind) { return !!kind; });
    return '<section class="studio-display-materials" aria-label="界面素材"><h2>界面素材</h2><div class="studio-display-card-grid">' + available.map(function (kind) {
      var args = Object.assign({}, snapshot.base, { blocks: [S.defaultBlock(kind, snapshot.base.caseId, snapshot.base.direction)] });
      return '<details class="studio-effect-card" data-effect-card="' + kind + '"><summary>' + E(names[kind]) + '</summary><div class="studio-card-effect" inert aria-label="' + E(names[kind]) + '的界面效果">' + S.renderPhone(args) + '</div></details>';
    }).join('') + '</div></section>';
  }
  function bindPreview(root) {
    if (S.bindPhoneInteractions) S.bindPhoneInteractions(root);
  }
  function buttonsDisabled(disabled) { return disabled ? ' disabled' : ''; }
  function renderLive() {
    var live = app.querySelector('.studio-live');
    if (live) live.innerHTML = '<div class="studio-preview-heading"><h2>' + (state.materials.material_preview ? '当前素材效果' : '当前方案预览') + '</h2></div>' + renderPhones(displaySnapshot);
    if (live) bindPreview(live);
    var badge = app.querySelector('.studio-header .badge');
    if (badge) badge.textContent = 'v' + state.studio_revision;
    var saveResult = app.querySelector('[data-save-result]');
    if (saveResult) saveResult.outerHTML = saveResultPanel();
    var undoButton = app.querySelector('[data-studio="undo"]');
    var redoButton = app.querySelector('[data-studio="redo"]');
    if (undoButton) undoButton.disabled = !state.undo_stack.length;
    if (redoButton) redoButton.disabled = !state.redo_stack.length;
    var notesInput = app.querySelector('#studio-notes');
    var confirmation = app.querySelector('[data-confirmation-status]');
    var confirmationToggle = app.querySelector('#studio-confirmed');
    if (confirmationToggle) confirmationToggle.checked = state.participant_confirmation.status === 'confirmed';
    if (confirmation && state.participant_confirmation.status !== 'confirmed') confirmation.textContent = '待参与者确认';
    var reason = app.querySelector('#studio-confirm-reason');
    if (reason && document.activeElement !== reason) reason.value = state.participant_confirmation.reason || '';
    var editor = app.querySelector('.studio-block-editor');
    if (editor) {
      var selected = state.blocks.find(function (b) { return b.id === selectedBlock; });
      var proposal = editor.querySelector('.studio-block-proposal');
      if (proposal) proposal.remove();
      if (selected && selected.participant_proposal) {
        proposal = document.createElement('p'); proposal.className = 'studio-warning studio-block-proposal'; proposal.textContent = '参与者内容提议，未作临床审核；冻结原文与差异已保留。'; editor.appendChild(proposal);
      }
    }
    renderBlockMarkers();
    if (storageProblem && !app.querySelector('[data-storage-warning]')) {
      var warning = document.createElement('p'); warning.className = 'studio-warning'; warning.dataset.storageWarning = 'true'; warning.textContent = storageProblem; app.querySelector('.studio-header').after(warning);
    }
  }
  function renderBlockMarkers() {
    app.querySelectorAll('.studio-select-block').forEach(function (button) {
      var block = state.blocks.find(function (b) { return b.id === button.dataset.id; });
      var old = button.querySelector('.studio-proposal-marker');
      if (old) old.remove();
      if (block && block.participant_proposal) {
        var marker = document.createElement('small'); marker.className = 'studio-proposal-marker'; marker.textContent = '参与者内容提议 · 未作临床审核'; marker.style.color = '#8a571d'; button.appendChild(marker);
      }
    });
  }
  function materialPanel() {
    var m = state.materials;
    if (m.stage === 'self') return '<section class="panel"><h2>先提出自己的方案</h2><p>记录参与者希望增加、修改或放置的内容。素材尚未开放。</p><div class="toolbar"><button class="btn" data-studio="add" data-kind="blank-text">添加空白文字</button><button class="btn" data-studio="add" data-kind="blank-button">添加空白按钮</button></div><button class="btn secondary" data-studio="start-materials">开放统一素材浏览</button></section>';
    if (m.stage === 'browse') {
      var step = browseSteps[m.browse_index];
      return '<section class="panel"><h2>统一浏览素材 <span class="badge">' + (m.browse_index + 1) + ' / 6</span></h2><p>' + step.map(function (k) { return E(k === 'D3p' ? 'D3′' : k) + ' · ' + E(names[k]); }).join(' ＋ ') + '</p><p class="muted">按固定顺序展示。当前效果已同步至参与者窗口。</p><div class="toolbar"><button class="btn" data-studio="previous-material"' + buttonsDisabled(m.browse_index === 0) + '>上一个</button><button class="btn primary" data-studio="next-material">' + (m.browse_index === 5 ? '完成浏览，开始选择' : '下一个素材') + '</button></div></section>';
    }
    return '<section class="panel"><h2>选择素材</h2><p class="muted">统一浏览已完成。按参与者选择，深入修改 2–3 项。</p><div class="studio-material-list">' + kinds.filter(function (k) { return k.charAt(0) === 'D'; }).map(function (kind) { return '<div><span><b>' + E(kind === 'D3p' ? 'D3′' : kind) + '</b> ' + E(names[kind]) + '</span><span><button class="btn" data-studio="preview-material" data-kind="' + kind + '">展示效果</button><button class="btn" data-studio="add" data-kind="' + kind + '">加入方案</button></span></div>'; }).join('') + '</div><div class="toolbar"><button class="btn" data-studio="add" data-kind="blank-text">添加空白文字</button><button class="btn" data-studio="add" data-kind="blank-button">添加空白按钮</button><button class="btn secondary" data-studio="show-design">展示当前方案</button></div></section>';
  }
  function blockPanel() {
    var selected = state.blocks.find(function (b) { return b.id === selectedBlock; });
    var list = state.blocks.length ? '<ol class="studio-block-list">' + state.blocks.map(function (block, index) {
      return '<li class="' + (block.id === selectedBlock ? 'selected' : '') + '"><button class="studio-select-block" data-studio="select-block" data-id="' + E(block.id) + '"><b>' + E(names[block.kind]) + '</b><small>' + E(positions[block.position]) + ' · ' + E(block.text || block.label || '').slice(0, 50) + '</small></button><div class="studio-audit-tags"><span>原始素材来源：' + E(block.original_source) + '</span><span>修改发起者：' + E(initiators[(block.modifications.slice(-1)[0] || {}).initiator || block.created_by] || block.created_by) + '</span></div><div class="toolbar"><button class="btn" aria-label="上移' + E(names[block.kind]) + '" data-studio="move-up" data-id="' + E(block.id) + '"' + buttonsDisabled(index === 0) + '>↑</button><button class="btn" aria-label="下移' + E(names[block.kind]) + '" data-studio="move-down" data-id="' + E(block.id) + '"' + buttonsDisabled(index === state.blocks.length - 1) + '>↓</button><button class="btn danger" data-studio="remove-block" data-id="' + E(block.id) + '">删除</button></div></li>';
    }).join('') + '</ol>' : '<p class="muted">当前保留起始界面。可添加文字或按钮。</p>';
    var editor = selected ? '<div class="studio-block-editor"><h3>编辑：' + E(names[selected.kind]) + '</h3><p class="muted">原始素材来源：' + E(selected.original_source) + '；创建发起者：' + E(initiators[selected.created_by] || selected.created_by) + '</p><label class="field">位置<select data-block-field="position" data-id="' + E(selected.id) + '">' + Object.keys(positions).map(function (p) { return '<option value="' + p + '"' + (selected.position === p ? ' selected' : '') + '>' + E(positions[p]) + '</option>'; }).join('') + '</select></label><label class="field">' + (selected.kind === 'blank-button' ? '按钮文字' : '标题或标签') + '<input data-block-field="label" data-id="' + E(selected.id) + '" value="' + E(selected.label || '') + '"></label>' + (selected.kind !== 'blank-button' ? '<label class="field">文字<textarea rows="5" data-block-field="text" data-id="' + E(selected.id) + '">' + E(selected.text || '') + '</textarea></label>' : '<label class="field">期待按钮打开后的行为<textarea rows="3" data-block-field="expected_behavior" data-id="' + E(selected.id) + '">' + E(selected.expected_behavior || '') + '</textarea></label>') + (selected.kind === 'D5' ? '<label class="studio-check"><input type="checkbox" data-block-field="collapsed" data-id="' + E(selected.id) + '"' + (selected.collapsed ? ' checked' : '') + '> 收起 AI 初步建议</label>' : '') + '<p class="muted">修改后离开输入框即保存到本场副本。</p></div>' : '';
    return '<section class="panel"><h2>方案中的模块</h2><p class="muted">先按插入位置排列，同一位置内按下列顺序展示。折叠模块控制 AI 消息。</p>' + list + editor + '</section>';
  }
  function clinicalPanel() {
    var fields = state.participant_proposal.fields;
    var changes = Object.keys(fields);
    return '<section class="panel"><h2>医学内容提议</h2><p class="muted">保留原稿，并记录独立的参与者提议。</p>' + (changes.length ? '<p class="studio-warning">参与者内容提议，未作临床审核 · 已修改 ' + changes.map(function (k) { return E(clinicalNames[k]); }).join('、') + '</p>' : '') + '<button class="btn" data-studio="clinical-toggle">' + (ui.clinicalOpen ? '收起提议编辑' : '打开正文提议编辑') + '</button>' + (ui.clinicalOpen ? '<div class="studio-clinical-fields">' + Object.keys(clinicalNames).map(function (key) {
      var field = fields[key];
      return '<div><h3>' + E(clinicalNames[key]) + '</h3><details><summary>查看冻结原稿</summary><p class="studio-original">' + E(state.base.original_content[key]) + '</p></details><label class="field">参与者提议<textarea rows="5" data-clinical="' + key + '">' + E(field ? field.proposed : state.base.original_content[key]) + '</textarea></label><button class="btn" data-studio="apply-clinical" data-field="' + key + '">应用这条提议</button>' + (field ? '<button class="btn secondary" data-studio="reset-clinical" data-field="' + key + '">恢复这条原稿</button><div class="studio-diff"><del>' + E(field.diff.removed) + '</del><ins>' + E(field.diff.added) + '</ins></div>' : '') + '</div>';
    }).join('') + '</div>' : '') + '</section>';
  }
  function confirmationPanel() {
    var c = state.participant_confirmation;
    return '<section class="panel"><h2>确认与备注</h2><label class="field">研究者备注<textarea rows="4" id="studio-notes">' + E(state.researcher_notes) + '</textarea></label><label class="studio-check"><input type="checkbox" id="studio-confirmed"' + (c.status === 'confirmed' ? ' checked' : '') + '>参与者已确认</label><p data-confirmation-status><strong>' + (c.status === 'confirmed' ? '参与者已确认' : '待参与者确认') + '</strong>' + (c.confirmed_at ? '<br><span class="muted">' + E(new Date(c.confirmed_at).toLocaleString()) + ' · v' + E(c.confirmed_revision) + '</span>' : '') + '</p><label class="field">未确认原因或确认说明<input id="studio-confirm-reason" value="' + E(c.reason || '') + '"></label></section>';
  }
  function saveResultPanel() {
    var record = state.save_records[state.save_records.length - 1];
    if (!record) return '';
    var bundled = record.archive_status === 'download_requested';
    var outcome = bundled ? '方案 ZIP 已生成，内含完整 PNG 和最终 JSON。' : record.png_status === 'exported' ? 'PNG 已生成。' : record.png_status === 'failed' ? 'PNG 未生成，可使用打印视图保存 PDF。' : record.archive_status === 'failed' ? 'ZIP 未能导出，可使用最终 JSON 和打印 PDF 交回方案。' : busy ? '正在生成方案文件。' : '上次导出未完成，可重新保存方案。';
    var jsonStatus = bundled ? '解压后核对两个文件及方案版本。' : record.json_export_stage === 'failed' ? 'JSON 导出失败，请使用“仅备份 JSON”重试并核对文件。' : ['after_png', 'standalone_fallback'].indexOf(record.json_export_stage) >= 0 ? '已发起最终 JSON 下载，文件包含本次图片生成结果。' : '方案已保存在本机。';
    if (record.print_fallback === 'failed') outcome += ' 打印视图未能打开，请保留 JSON 并重试保存。';
    var files = (bundled ? E(record.archive_filename) + '<br>内含：' : '') + E(record.png_filename) + '<br>' + E(record.json_filename);
    return '<section class="panel" data-save-result role="status"><h2>本次保存结果</h2><p>v' + E(record.studio_revision) + ' · ' + E(new Date(record.saved_at).toLocaleString()) + '</p><p>' + E(outcome) + ' ' + E(jsonStatus) + '</p><p class="muted">' + files + '</p>' + (record.studio_revision !== state.studio_revision ? '<p class="studio-warning">方案已修改至 v' + E(state.studio_revision) + '，请重新保存以取得对应文件。</p>' : '<p class="muted">请在下载目录核对文件后交回。</p>') + '</section>';
  }
  function render() {
    if (isDisplay) {
      app.innerHTML = '<main class="studio-display"><p class="studio-connection" role="status">' + (displayConnected && displaySnapshot ? '已连接' : '预览暂停') + '</p>' + (displayConnected && displaySnapshot ? renderPhones(displaySnapshot) + displayMaterials(displaySnapshot) : '<div class="studio-waiting">等待研究者连接</div>') + '</main>';
      bindPreview(app); return;
    }
    var reviewPending = !clinicalReady();
    app.innerHTML = '<main class="page-shell studio-shell"><header class="studio-header"><div><p class="eyebrow">研究者操作窗口</p><h1>共创设计工作台</h1><p>' + E(config.pid) + ' · ' + E(config.session_id) + ' · ' + E(caseData.title) + ' · 分身 / ' + E(direction) + ' <span class="badge">v' + state.studio_revision + '</span></p></div><div class="toolbar"><button class="btn primary" data-studio="open-display">打开展示窗口</button><button class="btn" data-studio="preview-only">本窗口全屏预览</button></div></header>' + (reviewPending ? '<p class="studio-warning">临床内容待审核：当前仅供研究者内部走查。</p>' : '') + (storageProblem ? '<p class="studio-warning">' + E(storageProblem) + '</p>' : '') + '<div class="studio-global toolbar"><button class="btn" data-studio="undo"' + buttonsDisabled(!state.undo_stack.length) + '>撤销</button><button class="btn" data-studio="redo"' + buttonsDisabled(!state.redo_stack.length) + '>重做</button><button class="btn" data-studio="reset-design">恢复本场起点</button><button class="btn primary" data-studio="save"' + buttonsDisabled(busy) + '>' + (busy ? '正在保存…' : '保存方案 ZIP（PNG + JSON）') + '</button><button class="btn" data-studio="backup">仅备份 JSON</button><label class="btn studio-file-label">载入方案 JSON<input type="file" id="studio-import" accept="application/json,.json"></label><button class="btn danger" data-studio="clear-session">清除本场</button></div>' + saveResultPanel() + '<div class="studio-grid"><aside class="studio-controls"><section class="panel"><h2>本次修改记录</h2><label class="field">修改发起者<select id="studio-initiator">' + Object.keys(initiators).map(function (key) { return '<option value="' + key + '"' + (ui.initiator === key ? ' selected' : '') + '>' + E(initiators[key]) + '</option>'; }).join('') + '</select></label><label class="field">修改理由或辅助说明<input id="studio-change-note" value="' + E(ui.changeNote) + '"></label><p class="muted">每次修改保存素材来源、发起者、阶段、时间与方案版本。</p></section>' + materialPanel() + blockPanel() + clinicalPanel() + confirmationPanel() + '<section class="panel"><h2>记录状态</h2><p>' + state.history.length + ' 次修订 · ' + state.events.length + ' 条事件</p><p class="muted">本场本地记录：' + E(new Date(state.updated_at).toLocaleString()) + '</p><details><summary>查看最近修订</summary><ol>' + state.history.slice(-8).reverse().map(function (item) { return '<li>v' + item.studio_revision + ' · ' + E(item.action) + ' · ' + E(initiators[item.initiator] || item.initiator) + (item.modification_note ? '<br>' + E(item.modification_note) : '') + '</li>'; }).join('') + '</ol></details></section></aside><section class="studio-live"><div class="studio-preview-heading"><h2>' + (state.materials.material_preview ? '当前素材效果' : '当前方案预览') + '</h2>' + (state.materials.material_preview ? '<button class="btn" data-studio="show-design"' + buttonsDisabled(state.materials.stage === 'browse') + '>返回方案</button>' : '') + '</div>' + renderPhones(displaySnapshot || publicState()) + '</section></div></main>';
    var selected = state.blocks.find(function (block) { return block.id === selectedBlock; });
    var editor = app.querySelector('.studio-block-editor');
    if (selected && selected.participant_proposal && editor) {
      var indicator = document.createElement('p'); indicator.className = 'studio-warning studio-block-proposal'; indicator.textContent = '参与者内容提议，未作临床审核；冻结原文与差异已保留。'; editor.appendChild(indicator);
    }
    if (selected && editor) {
      var labelField = editor.querySelector('[data-block-field="label"]');
      if (labelField && ['D1', 'D3p', 'D4', 'D5', 'blank-button'].indexOf(selected.kind) < 0) labelField.parentElement.style.display = 'none';
      var positionField = editor.querySelector('[data-block-field="position"]');
      if (positionField && selected.kind === 'D5') { positionField.disabled = true; positionField.title = '折叠模块固定作用于 AI 消息。'; }
    }
    renderBlockMarkers();
    bindPreview(app);
  }
  function validState(candidate) {
    if (!candidate || candidate.kind !== 'studio_design' || candidate.schema_version !== '1.0') throw new Error('请选择本工作台保存的方案 JSON。');
    if (!sameConfig(candidate.config, config)) throw new Error('文件的场次、参与者、分配或材料版本与当前链接不同。请从研究者入口打开文件对应场次后再载入。');
    if (candidate.session_id !== config.session_id || !candidate.base || candidate.base.caseId !== scenario.caseId || candidate.base.direction !== direction || candidate.base.identity !== 'avatar') throw new Error('方案起始配置与当前场次不一致，已停止载入。');
    if (JSON.stringify(candidate.base.original_content) !== JSON.stringify(originalFields())) throw new Error('文件的冻结原稿与当前材料不一致，请使用匹配版本的材料。');
    if (!Array.isArray(candidate.blocks) || !Array.isArray(candidate.history) || !Array.isArray(candidate.events) || !Array.isArray(candidate.undo_stack) || !Array.isArray(candidate.redo_stack) || !Array.isArray(candidate.save_records)) throw new Error('方案缺少完整修订或恢复记录。');
    var ids = new Set();
    candidate.blocks.forEach(function (block) {
      if (!block || typeof block.id !== 'string' || ids.has(block.id) || kinds.indexOf(block.kind) < 0 || !positions[block.position] || typeof block.text !== 'string' || typeof block.label !== 'string' || !Array.isArray(block.modifications)) throw new Error('模块结构不完整，已停止载入。');
      ids.add(block.id);
    });
    if (candidate.blocks.filter(function (b) { return b.kind === 'D5'; }).length > 1) throw new Error('方案包含重复折叠模块。');
    if (!candidate.participant_proposal || !candidate.participant_proposal.fields || !candidate.participant_confirmation || !candidate.materials || ['self', 'browse', 'edit'].indexOf(candidate.materials.stage) < 0 || !Array.isArray(candidate.materials.viewed) || !Number.isInteger(candidate.studio_revision) || candidate.studio_revision < 0) throw new Error('方案状态不完整，已停止载入。');
    Object.keys(candidate.participant_proposal.fields).forEach(function (key) { var f = candidate.participant_proposal.fields[key]; if (!clinicalNames[key] || typeof f.proposed !== 'string' || f.original !== candidate.base.original_content[key]) throw new Error('医学提议的原文记录不一致。'); });
    if (candidate.materials.stage === 'browse' && (!Number.isInteger(candidate.materials.browse_index) || candidate.materials.browse_index < 0 || candidate.materials.browse_index > 5)) throw new Error('素材浏览进度不完整。');
    candidate.events.forEach(function (event) { if (event.session_id !== config.session_id || !event.event_id) throw new Error('事件记录包含不同场次或缺失编号。'); });
    return candidate;
  }
  function exportedPayload() { var payload = copy(state); payload.exported_at = now(); return payload; }
  function fileBase() { return (config.session_id + '_studio_v' + state.studio_revision).replace(/[^\p{L}\p{N}_.-]/gu, '_'); }
  function backup() {
    eventRecord('studio_backup_exported', 'json'); persist();
    S.download(fileBase() + '_backup_' + now().replace(/[:.]/g, '-') + '.json', JSON.stringify(exportedPayload(), null, 2), 'application/json');
    note('本场方案与完整记录已导出为 JSON。');
  }
  async function save() {
    if (busy) return;
    busy = true;
    app.inert = true;
    var saveRecord = null;
    try {
      if (state.participant_confirmation.status !== 'confirmed' && !state.participant_confirmation.reason) state.participant_confirmation.reason = '本次保存时尚未完成参与者确认。';
      if (state.materials.material_preview) {
        state.materials.material_preview = null;
        persist();
      }
      render();
      var timestamp = now();
      var base = fileBase();
      saveRecord = { session_id: config.session_id, studio_revision: state.studio_revision, saved_at: timestamp, png_filename: base + '.png', json_filename: base + '.json', archive_filename: base + '.zip', archive_status: 'pending', png_status: 'pending', json_export_stage: 'pending', participant_confirmation: copy(state.participant_confirmation) };
      state.saved_at = timestamp;
      state.save_records.push(saveRecord);
      eventRecord('studio_save_started', 'design', '', { save_record: copy(saveRecord) });
      persist();
      // Keep an editable recovery snapshot locally, then issue one download.
      // PNG capture returns a Blob without triggering a second browser download.
      var phone = app.querySelector('[data-phone-preview="design"] .study-phone');
      var exportError = null;
      var png = null;
      try {
        if (!phone) throw new Error('手机预览未准备好。');
        png = await S.capturePhone(phone, base + '.png', { download: false });
        saveRecord.png_status = 'generated';
        eventRecord('studio_png_generated', 'png', base);
      } catch (error) {
        exportError = error;
        saveRecord.png_status = 'failed'; saveRecord.png_error = String(error.message || error);
        saveRecord.archive_status = 'not_created';
        eventRecord('studio_png_failed', 'png', saveRecord.png_error);
      }
      if (png) {
        saveRecord.archive_status = 'download_requested';
        saveRecord.archive_export_requested_at = now();
        saveRecord.json_export_stage = 'in_archive';
        var archiveEvent = eventRecord('studio_archive_export_requested', 'zip', base, { files: [saveRecord.png_filename, saveRecord.json_filename] });
        persist();
        try {
          if (!window.StudyZip) throw new Error('ZIP 导出模块未载入。');
          var archive = await window.StudyZip.create([
            { name: saveRecord.png_filename, data: png },
            { name: saveRecord.json_filename, data: JSON.stringify(exportedPayload(), null, 2) }
          ]);
          S.download(saveRecord.archive_filename, archive, 'application/zip');
          note('方案 ZIP 已生成，内含 PNG 和最终 JSON，请解压核对后交回。');
          return;
        } catch (error) {
          exportError = error;
          saveRecord.archive_status = 'failed'; saveRecord.archive_error = String(error.message || error);
          archiveEvent.event_type = 'studio_archive_export_failed'; archiveEvent.text = saveRecord.archive_error;
        }
      }
      // Rasterization or packaging failed: save the final editable JSON before
      // opening the print/PDF fallback. No success path downloads separate files.
      if (phone && S.printPhone) saveRecord.print_fallback = 'available';
      saveRecord.json_export_stage = 'standalone_fallback';
      saveRecord.json_export_requested_at = now();
      var jsonEvent = eventRecord('studio_json_exported', 'json', base, { png_status: saveRecord.png_status });
      persist();
      try {
        S.download(base + '.json', JSON.stringify(exportedPayload(), null, 2), 'application/json');
      } catch (error) {
        saveRecord.json_export_stage = 'failed';
        saveRecord.json_export_error = String(error.message || error);
        jsonEvent.event_type = 'studio_json_export_failed'; jsonEvent.text = saveRecord.json_export_error;
        persist();
        note('JSON 导出失败。方案仍在本场，请使用“仅备份 JSON”重试并核对文件。');
        return;
      }
      if (exportError && phone && S.printPhone) {
        try {
          S.printPhone(phone, base + '.pdf');
          saveRecord.print_fallback = 'opened';
          eventRecord('studio_print_fallback_opened', 'print', base);
          note('最终 JSON 已导出，已打开完整打印视图，可选择打印／保存 PDF。');
        } catch (error) {
          saveRecord.print_fallback = 'failed'; saveRecord.print_error = String(error.message || error);
          eventRecord('studio_print_fallback_failed', 'print', saveRecord.print_error);
          note('最终 JSON 已导出。打印视图未能打开，请保留 JSON 并重试保存。');
        }
      } else note('最终 JSON 已导出，请用浏览器打印保存方案画面。');
      persist();
    } catch (error) {
      if (saveRecord) saveRecord.save_error = String(error.message || error);
      eventRecord('studio_save_failed', 'save', String(error.message || error));
      persist();
      note('保存未完成，请核对本次保存结果并重试。');
    } finally {
      busy = false;
      app.inert = false;
      render();
    }
  }
  async function importFile(file) {
    if (!file) return;
    try {
      var loaded = validState(JSON.parse(await file.text()));
      if (state.history.length && !window.confirm('载入后将恢复文件中的完整方案。当前方案已在本地，可先取消并备份。继续载入吗？')) return;
      state = loaded;
      state.segment_id = S.uid('studio_segment');
      ui = { initiator: 'participant', changeNote: '', clinicalOpen: false };
      selectedBlock = null;
      eventRecord('studio_json_loaded', file.name, '', { restored_revision: state.studio_revision });
      persist(); render(); note('方案、折叠状态与修订记录已恢复。');
    } catch (error) { note(error.message || 'JSON 载入失败。'); }
  }
  function sendCommand(action, data) {
    var message = { type: 'studio-command', session_id: config.session_id, command_id: S.uid('preview_command'), action: action, data: data || {} };
    if (channel) channel.postMessage(message);
    try { localStorage.setItem(commandKey, JSON.stringify(message)); } catch (error) { /* The opener can receive file-origin commands. */ }
    if (window.opener && !window.opener.closed) window.opener.postMessage(message, '*');
  }
  function receiveCommand(message) {
    if (!state || !message.command_id || seenCommands.has(message.command_id)) return;
    seenCommands.add(message.command_id);
    if (seenCommands.size > 1000) seenCommands.delete(seenCommands.values().next().value);
    if (message.action === 'toggle-ai') {
      if (busy) { publish(); return; }
      var block = state.blocks.find(function (b) { return b.kind === 'D5'; });
      if (block && !state.materials.material_preview) {
        var old = ui.initiator;
        ui.initiator = 'participant'; updateBlock(block.id, 'collapsed', !!message.data.collapsed); ui.initiator = old;
      }
    } else if (message.action === 'preview-click') { eventRecord('studio_preview_interaction', message.data.target || '', '', { initiator: 'participant', preview_window: true }); persist(); }
  }
  function acceptMessage(message, source) {
    if (!message || message.session_id !== config.session_id) return;
    if (!isDisplay && !state) return;
    if (isDisplay && message.type === 'studio-heartbeat') {
      if (!Number.isFinite(Date.parse(message.sent_at)) || Date.now() - Date.parse(message.sent_at) > 8000) return;
      lastLiveSignal = Date.now();
      return;
    }
    if (isDisplay && message.type === 'studio-paused') { pauseDisplay(); return; }
    if (isDisplay && message.type === 'studio-preview') {
      if (!message.base || message.base.caseId !== scenario.caseId || message.base.direction !== direction || !Array.isArray(message.blocks)) return;
      if (!Number.isFinite(Date.parse(message.sent_at)) || Date.now() - Date.parse(message.sent_at) > 8000) return;
      lastLiveSignal = Date.now();
      var unchanged = displayConnected && displaySnapshot && JSON.stringify([displaySnapshot.base,displaySnapshot.blocks,displaySnapshot.participantProposal,displaySnapshot.materials]) === JSON.stringify([message.base,message.blocks,message.participantProposal,message.materials]);
      displayConnected = true;
      displaySnapshot = message;
      try { localStorage.setItem(displayKey, JSON.stringify(message)); } catch (error) { /* A direct file-window preview does not require storage. */ }
      if (unchanged) return;
      render();
    } else if (isDisplay && message.type === 'studio-cleared') { pauseDisplay(); try { localStorage.removeItem(displayKey); } catch (error) {} }
    else if (!isDisplay && message.type === 'studio-request') {
      if (source && typeof source.postMessage === 'function') { displayWindow = source; source.postMessage(publicState(), '*'); }
      else if (channel) channel.postMessage(publicState());
    } else if (!isDisplay && message.type === 'studio-command') receiveCommand(message);
  }
  function setupSync() {
    try { channel = new BroadcastChannel(channelName); channel.onmessage = function (event) { acceptMessage(event.data); }; } catch (error) { channel = null; }
    window.addEventListener('message', function (event) {
      if (event.origin !== window.location.origin && event.origin !== 'null') return;
      if (isDisplay && event.source !== window.opener) return;
      if (!isDisplay && displayWindow && event.source !== displayWindow) return;
      acceptMessage(event.data, event.source);
    });
    window.addEventListener('storage', function (event) {
      if (isDisplay && event.key === displayKey && event.newValue) { try { acceptMessage(JSON.parse(event.newValue)); } catch (error) { /* Ignore unrelated or unfinished storage writes. */ } }
      if (isDisplay && event.key === heartbeatKey + config.session_id && event.newValue) { try { acceptMessage(JSON.parse(event.newValue)); } catch (error) {} }
      if (isDisplay && event.key === displayKey && !event.newValue) pauseDisplay();
      if (!isDisplay && event.key === commandKey && event.newValue) { try { acceptMessage(JSON.parse(event.newValue)); } catch (error) { /* Ignore malformed commands. */ } }
    });
    if (isDisplay) {
      var ask = function () {
        // A previously stored snapshot alone never proves that a controller is live.
        if (displayConnected && Date.now() - lastLiveSignal > 8000) pauseDisplay();
        var request = { type: 'studio-request', session_id: config.session_id };
        if (channel) channel.postMessage(request);
        if (window.opener && !window.opener.closed) window.opener.postMessage(request, '*');
      };
      ask(); window.setInterval(ask, 1200);
    } else heartbeatTimer = window.setInterval(sendHeartbeat, 2000);
  }
  function openDisplay() {
    var url = new URL('display.html', window.location.href);
    url.search = window.location.search;
    displayWindow = window.open(url.href, 'studio_display_' + config.session_id.replace(/[^a-zA-Z0-9_-]/g, '_'));
    if (!displayWindow) return note('浏览器阻止了新窗口，请允许本页面弹出窗口后重试。');
    publish();
    eventRecord('studio_display_opened', 'display'); persist();
  }
  function previewOnly() {
    var previousFocus = document.activeElement;
    var background = Array.prototype.map.call(document.body.children, function (element) {
      return { element: element, inert: element.inert };
    });
    var wrap = document.createElement('div');
    wrap.className = 'studio-preview-overlay';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', 'true');
    wrap.setAttribute('aria-label', '界面预览');
    wrap.tabIndex = -1;
    wrap.innerHTML = '<button class="btn studio-exit-preview" aria-label="退出预览">返回工作台</button>' + renderPhones(publicState());
    background.forEach(function (entry) { entry.element.inert = true; });
    document.body.appendChild(wrap);
    bindPreview(wrap);
    function closePreview() {
      wrap.remove();
      background.forEach(function (entry) { entry.element.inert = entry.inert; });
      var target = previousFocus && previousFocus.isConnected ? previousFocus : app.querySelector('[data-studio="preview-only"]');
      if (target) target.focus();
    }
    wrap.querySelector('button').onclick = closePreview;
    wrap.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); closePreview(); return; }
      if (event.key !== 'Tab') return;
      var controls = Array.prototype.filter.call(wrap.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,[tabindex]:not([tabindex="-1"])'), function (element) { return element.getClientRects().length > 0; });
      var first = controls[0], last = controls[controls.length - 1];
      if (!first) { event.preventDefault(); wrap.focus(); return; }
      if (event.shiftKey && (document.activeElement === first || !wrap.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !wrap.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    });
    wrap.querySelector('button').focus();
  }
  function previewModal(action, element) {
    var old = document.querySelector('.studio-preview-modal');
    if (old) old.remove();
    var title = element.textContent.trim() || '入口预览';
    var modal = document.createElement('div');
    modal.className = 'studio-preview-modal'; modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true');
    modal.innerHTML = '<div class="panel"><h2>' + E(title) + '</h2><p>请向研究者描述：您希望这个入口打开后看到什么或完成什么。</p><button class="btn primary">返回方案</button></div>';
    modal.querySelector('button').onclick = function () { modal.remove(); element.focus(); };
    modal.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { event.preventDefault(); modal.remove(); element.focus(); }
      if (event.key === 'Tab') { event.preventDefault(); modal.querySelector('button').focus(); }
    });
    document.body.appendChild(modal); modal.querySelector('button').focus();
    if (isDisplay) sendCommand('preview-click', { target: action });
    else { eventRecord('studio_preview_interaction', action); persist(); }
  }
  function previewAction(event) {
    var action = event.target.closest('[data-action]');
    if (!action || !action.closest('.phone-wrap') || action.dataset.action === 'toggle-ai') return;
    event.preventDefault();
    previewModal(action.dataset.action, action);
  }
  function setCollapsed(event) {
    if (!isDisplay && busy) return;
    var details = event.target;
    if (!(details instanceof HTMLElement) || details.tagName !== 'DETAILS' || !details.querySelector('summary[data-action="toggle-ai"]')) return;
    var wrap = details.closest('[data-phone-preview]');
    if (!wrap || wrap.dataset.phonePreview !== 'design') return;
    var snapshot = isDisplay ? displaySnapshot : state;
    if (!snapshot) return;
    var block = snapshot.blocks.find(function (b) { return b.kind === 'D5'; });
    if (!block || !!block.collapsed === !details.open) return;
    if (isDisplay) sendCommand('toggle-ai', { collapsed: !details.open });
    else updateBlock(block.id, 'collapsed', !details.open);
  }
  function handleAction(action, element) {
    var id = element.dataset.id;
    if (action === 'add') return addBlock(element.dataset.kind);
    if (action === 'select-block') { selectedBlock = id; render(); return; }
    if (action === 'start-materials') { eventRecord('materials_opened', 'material-library'); return showMaterials(0); }
    if (action === 'previous-material') return showMaterials(Math.max(0, state.materials.browse_index - 1));
    if (action === 'next-material') {
      if (state.materials.browse_index < 5) return showMaterials(state.materials.browse_index + 1);
      return change('material_browse_completed', 'D1-D6+D3p', function () { state.materials.stage = 'edit'; state.materials.material_preview = null; }, { undoable: false, keepConfirmation: true });
    }
    if (action === 'preview-material') return change('material_preview_opened', element.dataset.kind, function () { state.materials.material_preview = element.dataset.kind; }, { undoable: false, keepConfirmation: true });
    if (action === 'show-design') return change('design_preview_opened', 'design', function () { state.materials.material_preview = null; }, { undoable: false, keepConfirmation: true });
    if (action === 'move-up' || action === 'move-down') {
      var index = state.blocks.findIndex(function (b) { return b.id === id; });
      var to = index + (action === 'move-up' ? -1 : 1);
      if (index < 0 || to < 0 || to >= state.blocks.length) return;
      return change('block_reordered', id, function () { var block = state.blocks.splice(index, 1)[0]; recordBlockChange(block, 'order', index, to); state.blocks.splice(to, 0, block); state.materials.material_preview = null; });
    }
    if (action === 'remove-block') {
      var source = sourceOf(id);
      return change('block_deleted', id, function () { state.blocks = state.blocks.filter(function (b) { return b.id !== id; }); if (selectedBlock === id) selectedBlock = null; state.materials.material_preview = null; }, { originalSource: source });
    }
    if (action === 'undo') return undo(false);
    if (action === 'redo') return undo(true);
    if (action === 'reset-design') {
      if (!window.confirm('恢复本场起始画面？当前模块和内容提议将从画面移除，完整修改记录仍保留，可使用撤销。')) return;
      return change('design_reset_to_start', 'design', function () { state.blocks = []; state.participant_proposal.fields = {}; state.materials.material_preview = null; selectedBlock = null; });
    }
    if (action === 'clinical-toggle') { ui.clinicalOpen = !ui.clinicalOpen; render(); return; }
    if (action === 'apply-clinical') {
      var field = element.dataset.field;
      var proposed = app.querySelector('[data-clinical="' + field + '"]').value;
      var original = state.base.original_content[field];
      if (!proposed.trim()) return note('请填写提议文字，或选择恢复原稿。');
      return change('clinical_proposal_changed', field, function () {
        if (proposed === original) delete state.participant_proposal.fields[field];
        else state.participant_proposal.fields[field] = { original: original, proposed: proposed, diff: textDiff(original, proposed), original_source: 'frozen_' + field, initiator: ui.initiator, modified_at: now(), studio_revision: state.studio_revision + 1, note: ui.changeNote, label: '参与者内容提议，未作临床审核' };
        state.materials.material_preview = null;
      }, { originalSource: 'frozen_' + field });
    }
    if (action === 'reset-clinical') return change('clinical_proposal_removed', element.dataset.field, function () { delete state.participant_proposal.fields[element.dataset.field]; }, { originalSource: 'frozen_' + element.dataset.field });
    if (action === 'confirm-design') return change('participant_design_confirmed', 'design', function () { state.participant_confirmation = { status: 'confirmed', confirmed_at: now(), confirmed_revision: state.studio_revision + 1, reason: app.querySelector('#studio-confirm-reason').value }; }, { keepConfirmation: true, undoable: false, extra: { initiator: 'participant' } });
    if (action === 'unconfirm-design') return change('participant_design_unconfirmed', 'design', function () { state.participant_confirmation = { status: 'pending', confirmed_at: null, confirmed_revision: null, reason: app.querySelector('#studio-confirm-reason').value }; }, { keepConfirmation: true, undoable: false });
    if (action === 'save') return save();
    if (action === 'backup') return backup();
    if (action === 'open-display') return openDisplay();
    if (action === 'preview-only') return previewOnly();
    if (action === 'clear-session') {
      if (!window.confirm('清除当前场次 ' + config.session_id + ' 的本机工作台记录？请先确认方案已导出并交回。')) return;
      try { localStorage.removeItem(storageKey); localStorage.removeItem(displayKey); localStorage.removeItem(commandKey); } catch (error) { return note('浏览器未允许清除本地数据。'); }
      clearPublicState();
      state = null;
      app.innerHTML = '<main class="page-shell panel"><h1>本场工作台记录已清除</h1><p>已清除本机当前场次的工作台记录。</p><button class="btn" id="studio-restart">重新开始本场</button></main>';
      app.querySelector('#studio-restart').onclick = function () { window.location.reload(); };
    }
  }

  function blocked(message) {
    app.innerHTML = '<main class="page-shell panel"><h1>' + (isDisplay ? '等待研究者准备' : '工作台尚未载入') + '</h1><p>' + E(message) + '</p></main>';
  }

  if (config.mode === 'study' && !clinicalReady()) { blocked('本版本临床审核记录尚未齐备，正式场次暂未开放。'); return; }
  document.addEventListener('click', previewAction);
  document.addEventListener('toggle', setCollapsed, true);
  document.addEventListener('study:phone-jump', function (event) {
    if (isDisplay) sendCommand('preview-click', { target: event.detail.target });
    else if (state) { eventRecord('studio_preview_interaction', event.detail.target, '', { expanded_ai: event.detail.expanded_ai }); persist(); }
  });
  document.addEventListener('toggle', function (event) {
    if (!isDisplay || !event.target.dataset || !event.target.dataset.effectCard || !event.target.open) return;
    sendCommand('preview-click', { target: 'material-effect:' + event.target.dataset.effectCard });
  }, true);
  if (isDisplay) { setupSync(); render(); return; }
  var stored = readStored(storageKey);
  try { state = stored ? validState(JSON.parse(stored)) : initialState(); }
  catch (error) { blocked(error.message + ' 当前本地数据已保留；请使用匹配的场次链接。'); return; }
  setupSync();
  eventRecord(stored ? 'studio_local_restored' : 'design_stage_started', 'studio');
  persist(); render();
  app.addEventListener('click', function (event) {
    var element = event.target.closest('[data-studio]');
    if (!element || element.disabled || !state || busy) return;
    event.preventDefault();
    handleAction(element.dataset.studio, element);
  });
  app.addEventListener('input', function (event) { if (event.target.id === 'studio-change-note') ui.changeNote = event.target.value; });
  app.addEventListener('change', function (event) {
    if (busy || !state) return;
    var element = event.target;
    if (element.id === 'studio-initiator') { ui.initiator = element.value; return; }
    if (element.id === 'studio-import') { importFile(element.files[0]); return; }
    if (element.id === 'studio-confirmed') { handleAction(element.checked ? 'confirm-design' : 'unconfirm-design', element); return; }
    if (element.dataset.blockField) { updateBlock(element.dataset.id, element.dataset.blockField, element.type === 'checkbox' ? element.checked : element.value); return; }
    if (element.id === 'studio-notes') { change('researcher_notes_changed', 'notes', function () { state.researcher_notes = element.value; }, { keepConfirmation: true, render: false, extra: { initiator: 'researcher' } }); return; }
    if (element.id === 'studio-confirm-reason') change('confirmation_reason_changed', 'confirmation', function () { state.participant_confirmation.reason = element.value; }, { keepConfirmation: true, render: false });
  });
  window.addEventListener('beforeunload', function () { if (state) persist(); });
  window.addEventListener('pagehide', function () {
    if (!state) return;
    window.clearInterval(heartbeatTimer);
    var message = { type: 'studio-paused', session_id: config.session_id };
    if (channel) channel.postMessage(message);
    if (displayWindow && !displayWindow.closed) displayWindow.postMessage(message, '*');
    try { localStorage.removeItem(displayKey); localStorage.removeItem(heartbeatKey + config.session_id); } catch (error) {}
  });
  window.StudyStudio = { getState: function () { return copy(state); }, validate: validState, publicSnapshot: function () { return copy(publicState()); } };
})();
