(function () {
  'use strict';

  var S = window.Study;
  var C = window.StudyContent;
  var app = document.getElementById('app');
  if (!app || !S || !C) return;

  var PREFIX = 'one-physician:session:';
  var SCHEMA = '1.0';
  var REQUIRED_CONFIG = ['pid', 'session_id', 'order', 'directions', 'mode', 'study_material_version', 'content_version'];
  var CONTACTS = ['contact-doctor', 'contact-ai', 'contact-platform', 'other'];
  var ACTIONS = ['basis', 'source'].concat(CONTACTS, ['end-consultation']);
  var config, state, events = [], block = null, storageError = '', modal = null;
  var importCandidate = null, storageVersion = null, controlsOpen = false, cleared = false;
  var requested = null, restoredNotice = '', viewportTimer = null, restoringViewport = false, menuOpen = false;
  var exportEnabled = !C.ui_preferences || C.ui_preferences.participant_export_enabled !== false;
  // Host controls are a separate, explicitly opened surface; never render them in the participant view.
  var hostControls = new URLSearchParams(location.search).get('host') === '1';
  var HOST_ACTIONS = ['accidental', 'handoff', 'finish-study', 'supplement', 'design'];

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function now() { return new Date().toISOString(); }
  function esc(value) { return S.esc(value == null ? '' : String(value)); }
  function stable(value) {
    if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
    if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(function (key) { return JSON.stringify(key) + ':' + stable(value[key]); }).join(',') + '}';
    return JSON.stringify(value);
  }
  function key() { return PREFIX + config.session_id; }
  function scenario() { return config.assigned_scenarios[Math.max(0, (state.scenario_index || 1) - 1)]; }
  function caseData() { return C.cases[scenario().caseId]; }
  function history() { return state.scenarios[Math.max(0, (state.scenario_index || 1) - 1)]; }
  function isActive() { return !block && !cleared && state.status === 'active'; }
  function isStopped() { return state.status === 'withdrawn' || state.status === 'study_complete'; }
  function localMode() { return location.protocol === 'file:' ? 'offline' : 'online'; }
  function button(action, label, style, disabled) {
    return '<button type="button" class="btn ' + (style || 'secondary') + '" data-control="' + action + '"' + (disabled ? ' disabled' : '') + '>' + esc(label) + '</button>';
  }
  function identityTitle() { return S.tpl(C.identity_templates[scenario().identity].title, caseData().doctor); }
  function textUI(keyName, fallback) { return C.shared_ui[keyName] || fallback; }
  function coreConfig(value) {
    var core = {};
    REQUIRED_CONFIG.forEach(function (field) { core[field] = value[field]; });
    return core;
  }
  function configDifferences(a, b) {
    return REQUIRED_CONFIG.filter(function (field) { return stable(a[field]) !== stable(b[field]); });
  }
  function normalizeConfig(value) {
    if (!value || typeof value !== 'object') throw new Error('记录中缺少场次配置。');
    var c = clone(value);
    ['pid', 'session_id'].forEach(function (field) {
      if (typeof c[field] !== 'string' || !(field === 'pid' ? /^[A-Za-z0-9_-]{1,80}$/ : /^[A-Za-z0-9_-]{1,100}$/).test(c[field])) throw new Error('编号只可使用字母、数字、下划线和短横线；参与者编号最多80字，场次编号最多100字。');
    });
    if (!/^S[1-4]$/.test(c.order)) throw new Error('顺序必须为 S1–S4。');
    if (!Array.isArray(c.directions) || c.directions.length !== 2 || c.directions.some(function (d) { return d !== 'XY' && d !== 'YX'; })) throw new Error('两个情境的建议方向必须分别为 XY 或 YX。');
    if (c.mode !== 'preview' && c.mode !== 'study') throw new Error('运行模式必须为 preview 或 study。');
    ['study_material_version', 'content_version'].forEach(function (field) {
      if (typeof c[field] !== 'string' || !c[field]) throw new Error('缺少材料版本：' + field);
    });
    var assignments = S.scenarios(c.order);
    if (!Array.isArray(assignments) || assignments.length !== 2) throw new Error('情境配置不可用。');
    if (c.assigned_scenarios && stable(c.assigned_scenarios.map(function (a) { return {caseId: a.caseId, identity: a.identity}; })) !== stable(assignments.map(function (a) { return {caseId: a.caseId, identity: a.identity}; }))) throw new Error('保存的情境分配与顺序不一致。');
    c.assigned_scenarios = assignments.map(function (a, index) {
      var clinicalCase = C.cases[a.caseId];
      if (!clinicalCase || !clinicalCase.doctor || !clinicalCase.advice) throw new Error('情境内容尚未齐备。');
      return {caseId: a.caseId, identity: a.identity, direction: c.directions[index], doctor_id: clinicalCase.doctor.id || 'case_' + a.caseId + '_doctor', doctor_name: clinicalCase.doctor.name, clinical_stage: clinicalCase.stage};
    });
    if (!c.reply_times) c.reply_times = clone(C.supplements.times);
    if (!c.clinical_review_status) c.clinical_review_status = clone(C.clinical_review_status);
    if (!c.snapshot_created_at) c.snapshot_created_at = now();
    return c;
  }
  function runtimeVersionIssue(c) {
    if (c.content_version !== C.content_version || c.study_material_version !== C.study_material_version) return '本场保存的材料版本与当前页面不同。请打开对应版本后恢复；现有记录可导出。';
    return '';
  }
  function clinicalReady() {
    var review = C.clinical_review_status || {};
    return review.status === 'approved' && !!review.record_id && config.assigned_scenarios.every(function (a) {
      var item = C.cases[a.caseId].clinical_review_status;
      return item === 'approved' || (item && item.status === 'approved');
    });
  }
  function canRun() { return !runtimeVersionIssue(config) && (config.mode === 'preview' || clinicalReady()); }
  function makeState() {
    var timestamp = now(), segment = S.uid('segment');
    return {
      status: 'ready', scenario_index: 0, phase: 'start', segment_id: segment,
      created_at: timestamp, updated_at: timestamp, started_at: null,
      phase_entered_at: timestamp, walkthrough_completed_at: null,
      study_completed_at: null, withdrawn_at: null, handoff: null,
      scenarios: config.assigned_scenarios.map(function (a, i) { return {
        scenario_index: i + 1, case_id: a.caseId, started_at: null, ai_revealed_at: null,
        doctor_revealed_at: null, consultation_ended: false, consultation_ended_at: null,
        completed_at: null, first_choice: null, initial_understanding_exposed: false, accidental_reveals: []
      }; }),
      segments: [{segment_id: segment, started_at: timestamp, environment: localMode(), reason: 'initial'}],
      checkpoints: [], last_export: null, revision: 0, viewport: null, checkpoint_saved: null
    };
  }
  function envelope(reason) {
    return {schema_version: SCHEMA, kind: 'participant_log', config: clone(config), state: clone(state), events: clone(events), exported_at: now(), export_reason: reason || 'snapshot'};
  }
  function record(type, target, text, extra) {
    var assigned = state.scenario_index ? scenario() : null;
    var event = {
      event_id: S.uid('event'), session_id: config.session_id, segment_id: state.segment_id,
      pid: config.pid, event_time: now(), sequence_no: events.reduce(function (n, e) { return Math.max(n, Number(e.sequence_no) || 0); }, 0) + 1,
      order: config.order, scenario_index: state.scenario_index || 0,
      case_id: assigned ? assigned.caseId : null, doctor_id: assigned ? assigned.doctor_id : null,
      identity: assigned ? assigned.identity : null, direction: assigned ? assigned.direction : null,
      phase: state.phase, event_type: type, target: target || null, text: text == null ? '' : String(text),
      study_material_version: config.study_material_version, content_version: config.content_version, source: 'prototype'
    };
    Object.keys(extra || {}).forEach(function (name) { event[name] = extra[name]; });
    events.push(event);
    return event;
  }
  function persist() {
    if (cleared || block) return false;
    state.updated_at = now();
    state.revision = (state.revision || 0) + 1;
    try {
      var existing = localStorage.getItem(key());
      if (existing && storageVersion !== null && existing !== storageVersion) {
        block = {type: 'concurrent', message: '同一场次已在另一个窗口更新。请先导出此窗口记录，再刷新载入最新记录。'};
        return false;
      }
      var serialized = JSON.stringify(envelope('local_checkpoint'));
      localStorage.setItem(key(), serialized);
      storageVersion = serialized;
      storageError = '';
      return true;
    } catch (error) {
      storageError = '浏览器未能持久保存本场记录。请立即导出当前记录，并在已验证的设备继续。';
      return false;
    }
  }
  function checkpoint(reason) {
    state.checkpoints.push({checkpoint_id: S.uid('checkpoint'), created_at: now(), reason: reason, segment_id: state.segment_id, scenario_index: state.scenario_index, phase: state.phase, status: state.status, last_event_id: events.length ? events[events.length - 1].event_id : null, event_count: events.length});
  }
  function setPhase(status, index, phase) {
    state.status = status;
    state.scenario_index = index;
    state.phase = phase;
    state.phase_entered_at = now();
  }
  function captureViewport() {
    if (!state || state.status !== 'active' || block || cleared) return;
    var phone = app.querySelector('.study-phone');
    state.viewport = {scenario_index: state.scenario_index, phase: state.phase,
      window_y: Math.max(0, Number(window.scrollY) || 0),
      phone_y: phone ? Math.max(0, Number(phone.scrollTop) || 0) : 0};
  }
  function scheduleViewportSave() {
    if (restoringViewport || modal || !isActive()) return;
    clearTimeout(viewportTimer);
    viewportTimer = setTimeout(function () { captureViewport(); persist(); }, 180);
  }
  function restoreViewport() {
    var point = state.viewport;
    if (!point || point.scenario_index !== state.scenario_index || point.phase !== state.phase) return;
    restoringViewport = true;
    var phone = app.querySelector('.study-phone');
    if (phone) phone.scrollTop = Math.max(0, Number(point.phone_y) || 0);
    if (window.scrollTo) window.scrollTo({top: Math.max(0, Number(point.window_y) || 0), behavior: 'auto'});
    requestAnimationFrame(function () { restoringViewport = false; });
  }
  function saveRender(scrollId) {
    var previousFocus = focusTarget(document.activeElement);
    if (!scrollId) captureViewport();
    else state.viewport = null;
    state.checkpoint_saved = persist();
    render();
    if (!scrollId) restoreFocus(previousFocus);
    if (scrollId) requestAnimationFrame(function () {
      if (scrollId === 'doctor-message') S.scrollToSystem(app);
      else S.resetPhoneScroll(app);
      captureViewport();
      persist();
    });
  }
  function safeFilename(value) { return String(value).replace(/[^A-Za-z0-9._-]/g, '_'); }
  function exportLog(reason) {
    if (!state || !config || cleared || !exportEnabled) return;
    captureViewport();
    if (block && block.type === 'invalid_saved' && block.raw) {
      S.download(safeFilename(config.session_id) + '_unreadable_original.json', block.raw, 'application/json');
      S.notice('已导出本机原始记录，请由研究者核对文件。');
      return;
    }
    var at = now(), filename = [config.pid, config.session_id, state.segment_id, at.replace(/[:.]/g, '-')].map(safeFilename).join('_') + '.json';
    state.last_export = {filename: filename, exported_at: at, reason: reason || 'manual'};
    record('log_exported', reason || 'manual', '', {filename: filename});
    persist();
    try {
      S.download(filename, JSON.stringify(envelope(reason || 'manual'), null, 2), 'application/json');
      S.notice('已生成记录文件。请在浏览器下载位置确认文件。');
    } catch (error) {
      S.notice('下载未成功，请再点“导出当前记录”。');
    }
    render();
  }
  function closeModal(cancel) {
    if (!modal) return;
    var previous = modal;
    modal = null;
    previous.element.remove();
    document.body.classList.remove('participant-modal-open');
    if (cancel && previous.onCancel) previous.onCancel();
    if (previous.viewportCleanup) previous.viewportCleanup();
    app.inert = false;
    restoreFocus(previous.returnFocus);
  }
  function focusTarget(element) {
    if (!element) return null;
    var attribute = element.getAttribute && (element.getAttribute('data-action') ? 'data-action' : element.getAttribute('data-control') ? 'data-control' : null);
    return {element: element, selector: attribute ? '[' + attribute + '="' + element.getAttribute(attribute) + '"]' : element.id ? '#' + element.id : null};
  }
  function restoreFocus(target) {
    if (!target) return;
    var element = target.element;
    if (!element || !element.isConnected) element = target.selector ? app.querySelector(target.selector) : null;
    if (element && element.disabled) element = app.querySelector('[data-control="next"]');
    if (element && element.focus) element.focus();
  }
  function showModal(title, body, options) {
    closeModal(false);
    options = options || {};
    var returnFocus = options.returnFocus || focusTarget(document.activeElement);
    var element = document.createElement('div');
    element.className = 'participant-modal-shade';
    element.innerHTML = '<section class="participant-modal panel" role="dialog" aria-modal="true" aria-labelledby="participant-modal-title" tabindex="-1"><div class="participant-modal-heading"><h2 id="participant-modal-title">' + esc(title) + '</h2><button type="button" class="btn secondary" data-dialog="cancel" aria-label="关闭弹窗">关闭</button></div><form id="participant-modal-form">' + body + '<div class="toolbar participant-modal-actions">' + (options.confirm ? '<button type="submit" class="btn ' + (options.danger ? 'danger' : 'primary') + '">' + esc(options.confirm) + '</button>' : '') + '<button type="button" class="btn secondary" data-dialog="cancel">' + esc(options.confirm ? textUI('cancel', '取消') : textUI('close', '关闭')) + '</button></div></form></section>';
    document.body.appendChild(element);
    document.body.classList.add('participant-modal-open');
    modal = {element: element, onCancel: options.onCancel, returnFocus: returnFocus};
    app.inert = true;
    // Size the bottom sheet to the visual viewport when a mobile keyboard opens.
    if (window.visualViewport) {
      var fitViewport = function () {
        element.style.height = window.visualViewport.height + 'px';
        element.style.top = window.visualViewport.offsetTop + 'px';
        element.style.bottom = 'auto';
      };
      window.visualViewport.addEventListener('resize', fitViewport);
      window.visualViewport.addEventListener('scroll', fitViewport);
      fitViewport();
      modal.viewportCleanup = function () {
        window.visualViewport.removeEventListener('resize', fitViewport);
        window.visualViewport.removeEventListener('scroll', fitViewport);
      };
    }
    element.addEventListener('click', function (event) { if (event.target.closest('[data-dialog="cancel"]')) closeModal(true); });
    element.querySelector('form').addEventListener('submit', function (event) {
      event.preventDefault();
      if (options.onConfirm) options.onConfirm(element.querySelector('form'));
    });
    element.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { event.preventDefault(); closeModal(true); }
      if (event.key === 'Tab') {
        var focusable = Array.prototype.slice.call(element.querySelectorAll('button:not([disabled]), input, textarea, select, [tabindex="0"]'));
        var first = focusable[0], last = focusable[focusable.length - 1];
        if (!first) return;
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    });
    element.querySelector('textarea, input, select, button').focus();
  }
  function formValue(form, name) {
    var field = form.elements.namedItem(name);
    return field ? String(field.value || '').trim() : '';
  }
  function textarea(name, label, placeholder) {
    return '<label class="field">' + esc(label) + '<textarea name="' + name + '" rows="4" maxlength="10000" placeholder="' + esc(placeholder || '') + '"></textarea></label>';
  }
  function openedAction(action) {
    if (!history().first_choice) history().first_choice = {target: action, event_time: now()};
    record('action_selected', action, '', {first_choice: history().first_choice.target === action && !events.some(function (e) { return e.event_type === 'action_selected' && e.scenario_index === state.scenario_index; })});
  }
  function openAction(action) {
    if (!isActive() || state.phase !== 'both' || ACTIONS.indexOf(action) < 0) return;
    if (history().consultation_ended && (CONTACTS.indexOf(action) >= 0 || action === 'end-consultation')) return;
    openedAction(action);
    var d = caseData().doctor;
    if (action === 'basis' || action === 'source') {
      record('panel_opened', action);
      persist();
      var body;
      if (action === 'basis') {
        body = '<h3>' + esc(identityTitle()) + '</h3><p class="preserve-lines">' + esc(caseData().advice[scenario().direction[0]].rationale) + '</p><h3>' + esc(d.name) + '</h3><p class="preserve-lines">' + esc(caseData().advice[scenario().direction[1]].rationale) + '</p>';
      } else {
        body = '<h3>' + esc(identityTitle()) + '</h3><p>' + esc(C.shared_ui.technical) + '</p><p>' + esc(S.tpl(C.shared_ui.review, d)) + '</p><h3>' + esc(d.name) + '</h3><p>' + esc(S.tpl(textUI('source_doctor', '在情境设定中，医生回复由{doctor}本人撰写。'), d)) + '</p>';
      }
      showModal(action === 'basis' ? '建议依据' : '来源与审核说明', body, {onCancel: function () { record('panel_closed', action); saveRender(); }});
      return;
    }
    if (action === 'end-consultation') {
      record('consultation_end_opened', action);
      persist();
      showModal('结束本次模拟咨询', '<p>结束后仍可查看本次建议和依据，并继续研究流程。</p>', {
        confirm: '结束本次咨询', onCancel: function () { record('consultation_end_cancelled', action); saveRender(); }, onConfirm: function () {
          if (!isActive()) return;
          history().consultation_ended = true;
          history().consultation_ended_at = now();
          record('consultation_ended', action);
          checkpoint('consultation_ended');
          closeModal(false);
          saveRender();
        }
      });
      return;
    }
    var names = {'contact-doctor': '联系' + d.name, 'contact-ai': '询问 AI', 'contact-platform': '联系平台', other: '找另一位医生'};
    var questions = {'contact-doctor': '你想对这位医生说什么或问什么？', 'contact-ai': '你想对 AI 说什么或问什么？', 'contact-platform': '你想对平台客服说什么或问什么？', other: '你希望找什么样的医生、问什么？'};
    record('contact_opened', action);
    persist();
    var actionContent = (C.shared_ui.actions || []).filter(function (item) { return item.id === action; })[0];
    showModal(names[action], '<p class="participant-input-hint">' + esc(textUI('input_hint', '请围绕模拟情境填写，无需输入真实姓名、联系方式或病历。')) + '</p>' + textarea('message', actionContent && actionContent.prompt || questions[action], '可以留空'), {
      confirm: action === 'other' ? '记录选择' : '模拟发送',
      onCancel: function () { record('contact_cancelled', action); saveRender(); },
      onConfirm: function (form) {
        if (!isActive() || history().consultation_ended) return;
        record('contact_submitted', action, formValue(form, 'message'));
        var returnFocus = modal.returnFocus;
        closeModal(false);
        saveRender();
        showModal('已记录', '<p>' + esc(textUI('simulated_submission', '（模拟）已记录。本演示不会向医生或平台发送，也不会产生实际回复。')) + '</p>', {returnFocus: returnFocus});
      }
    });
  }
  function startScenario(index) {
    restoredNotice = '';
    menuOpen = false;
    controlsOpen = false;
    state.viewport = null;
    setPhase('active', index, 'ai');
    var item = history();
    item.started_at = item.started_at || now();
    item.ai_revealed_at = item.ai_revealed_at || now();
    record('scenario_started', 'scenario_' + index);
    checkpoint('scenario_started');
  }
  function start() {
    if (block || cleared || state.status !== 'ready' || !canRun()) return;
    state.started_at = now();
    record('session_started', 'start');
    startScenario(1);
    saveRender('participant-scene');
  }
  function reveal(reason) {
    if (!isActive() || state.phase !== 'ai' || !canRun()) return;
    restoredNotice = '';
    menuOpen = false;
    setPhase('active', state.scenario_index, 'both');
    history().doctor_revealed_at = now();
    record('doctor_reply_revealed', 'doctor-message', '', {reveal_reason: reason || 'participant_click'});
    checkpoint('doctor_reply_revealed');
    saveRender('doctor-message');
  }
  function next() {
    if (!isActive() || state.phase !== 'both' || !canRun()) return;
    history().completed_at = now();
    record('scenario_completed', 'scenario_' + state.scenario_index);
    checkpoint('scenario_completed');
    if (state.scenario_index === 1) {
      record('next_scenario', 'scenario_2');
      startScenario(2);
      saveRender('participant-scene');
    } else {
      setPhase('walkthrough_complete', 2, 'complete');
      state.walkthrough_completed_at = now();
      record('walkthrough_completed', 'two_scenarios');
      checkpoint('two_scenarios_complete');
      saveRender('participant-scene');
      exportLog('two_scenarios_backup');
    }
  }
  function accidental() {
    if (!isActive()) return;
    showModal('记录提前接触医生回复', textarea('reason', '提前接触的原因', '例如：误点查看、在其他画面看到') + textarea('handling', '主持人如何处理', '记录实际处理与初始理解受影响的范围') + '<p class="muted">记录当前时间，并将本情境的初始理解标注为已提前接触医生回复。</p>', {
      confirm: state.phase === 'ai' ? '记录并显示医生回复' : '保存标记', onConfirm: function (form) {
        if (!isActive()) return;
        var detail = {marked_at: now(), reason: formValue(form, 'reason'), moderator_action: formValue(form, 'handling'), phase_at_marking: state.phase};
        history().initial_understanding_exposed = true;
        history().accidental_reveals.push(detail);
        record('unexpected_reveal', 'doctor-message', detail.reason, {legacy_event_type: 'accidental_reveal', source: 'researcher', moderator_action: detail.moderator_action, initial_understanding_exposed: true, exposure_marked_at: detail.marked_at});
        closeModal(false);
        if (state.phase === 'ai') reveal('accidental'); else saveRender();
      }
    });
  }
  function withdraw() {
    if (block || cleared || isStopped()) return;
    showModal('退出本场研究', '<p>确认后将停止本场流程。已有记录可按已同意的安排导出交回或清除。</p>' + textarea('reason', '备注（可留空）'), {
      confirm: '确认退出研究', danger: true, onConfirm: function (form) {
        if (isStopped()) return;
        var previous = {status: state.status, scenario_index: state.scenario_index, phase: state.phase};
        state.withdrawn_at = now();
        state.stopped_at = previous;
        setPhase('withdrawn', state.scenario_index, 'withdrawn');
        record('study_withdrawn', 'whole_study', formValue(form, 'reason'), {stopped_at: previous});
        checkpoint('study_withdrawn');
        closeModal(false);
        saveRender('participant-scene');
      }
    });
  }
  function handoff() {
    if (block || cleared) return;
    var prior = state.last_export;
    showModal('确认记录已交回', '<p>请由研究者打开收到的 JSON，核对场次、版本、情境、事件和文字后填写。</p><label class="field">收到的文件名<input name="filename" required maxlength="400" value="' + esc(prior ? prior.filename : '') + '"></label><label class="field">核对结果<select name="result"><option value="complete">已打开核对，记录完整</option><option value="partial">已收到，存在缺失／待补</option></select></label>' + textarea('notes', '交回渠道与缺失／待补情况') + '<label class="participant-check"><input type="checkbox" name="verified" required>研究者已打开文件核对</label>', {
      confirm: '保存交回确认', onConfirm: function (form) {
        if (!form.elements.namedItem('verified').checked || !formValue(form, 'filename')) return;
        state.handoff = {confirmed_at: now(), filename: formValue(form, 'filename'), result: formValue(form, 'result'), notes: formValue(form, 'notes'), researcher_verified: true};
        record('handoff_confirmed', state.handoff.filename, state.handoff.notes, {source: 'researcher', handoff_result: state.handoff.result});
        checkpoint('handoff_confirmed');
        closeModal(false);
        saveRender();
        exportLog('handoff_receipt');
      }
    });
  }
  function clearCurrent() {
    if (cleared || !config) return;
    showModal('清除本场记录', '<p>将清除此浏览器保存的场次 <strong>' + esc(config.session_id) + '</strong>。在线页面与离线文件中的本地记录需分别处理。</p><p class="muted">下载文件与已交回副本按约定分别处理。</p><label class="participant-check"><input type="checkbox" name="confirmed" required>' + (state && state.status === 'withdrawn' ? '已确认退出后的数据处理安排，清除当前设备本场记录' : '已确认交回或已有记录的处理安排，清除当前设备本场记录') + '</label>', {
      confirm: '确认清除当前场次', danger: true, onConfirm: function (form) {
        if (!form.elements.namedItem('confirmed').checked) return;
        try { localStorage.removeItem(key()); } catch (error) { S.notice('清除失败，请检查浏览器存储设置。'); return; }
        closeModal(false);
        events = [];
        storageVersion = null;
        cleared = true;
        block = null;
        render();
      }
    });
  }
  function finishStudy() {
    if (block || state.status !== 'walkthrough_complete') return;
    showModal('确认整场研究完成', '<p>在比较、设计确认和收尾完成后记录整场结束。</p>', {confirm: '记录整场完成', onConfirm: function () {
      state.study_completed_at = now();
      setPhase('study_complete', state.scenario_index, 'complete');
      record('study_completed', 'whole_study', '', {source: 'researcher'});
      checkpoint('study_completed');
      closeModal(false);
      saveRender();
      exportLog('final_record');
    }});
  }
  function researcherNote(kind) {
    if (block || (state.status !== 'walkthrough_complete' && state.status !== 'active')) return;
    var supplement = kind === 'supplement';
    showModal(supplement ? '记录补充材料展示' : '记录设计阶段开始', (supplement ? '<label class="field">素材编号<input name="supplement_id" required maxlength="100"></label>' : '') + textarea('notes', supplement ? '展示原因与讨论情况' : '备注'), {confirm: '保存记录', onConfirm: function (form) {
      var supplementId = formValue(form, 'supplement_id');
      if (supplement && !supplementId) return;
      record(supplement ? 'supplement_shown' : 'design_started', supplement ? supplementId : 'co_design', formValue(form, 'notes'), {source: 'researcher', supplement_id: supplement ? supplementId : null});
      closeModal(false);
      saveRender();
    }});
  }
  function validateEnvelope(input) {
    if (!input || input.schema_version !== SCHEMA || input.kind !== 'participant_log') throw new Error('请选择本原型导出的 participant_log JSON 文件。');
    var c = normalizeConfig(input.config);
    if (!input.state || !Array.isArray(input.events) || input.events.length > 100000) throw new Error('文件缺少状态或事件列表。');
    var st = clone(input.state);
    if (['ready', 'active', 'walkthrough_complete', 'study_complete', 'withdrawn'].indexOf(st.status) < 0 || [0, 1, 2].indexOf(st.scenario_index) < 0 || !st.segment_id) throw new Error('断点状态不正确。');
    if (st.status === 'active' && (!st.scenario_index || ['ai', 'both'].indexOf(st.phase) < 0)) throw new Error('活动情境的阶段不正确。');
    if (!Array.isArray(st.scenarios) || st.scenarios.length !== 2 || !Array.isArray(st.segments) || !Array.isArray(st.checkpoints)) throw new Error('记录缺少情境或记录段信息。');
    st.scenarios.forEach(function (item, index) {
      if (item.case_id !== c.assigned_scenarios[index].caseId || !Array.isArray(item.accidental_reveals)) throw new Error('情境历史与分配配置不一致。');
    });
    var ids = Object.create(null);
    input.events.forEach(function (event) {
      if (!event || typeof event.event_id !== 'string' || !event.segment_id || event.session_id !== c.session_id || event.pid !== c.pid || !Number.isInteger(event.sequence_no) || event.sequence_no < 1 || typeof event.event_type !== 'string' || !event.event_time) throw new Error('文件中的事件字段不完整或场次不一致。');
      if (event.order !== c.order || event.study_material_version !== c.study_material_version || event.content_version !== c.content_version || [0, 1, 2].indexOf(event.scenario_index) < 0 || ['prototype', 'researcher'].indexOf(event.source) < 0) throw new Error('事件的分配、版本或来源与场次配置不一致。');
      if (event.scenario_index) {
        var assignment = c.assigned_scenarios[event.scenario_index - 1];
        if (event.case_id !== assignment.caseId || event.doctor_id !== assignment.doctor_id || event.identity !== assignment.identity || event.direction !== assignment.direction) throw new Error('事件的病例、医生或建议方向与分配不一致。');
      }
      if (ids[event.event_id]) throw new Error('文件含有重复的 event_id，请在研究者端核对原始文件。');
      ids[event.event_id] = true;
    });
    return {schema_version: SCHEMA, kind: 'participant_log', config: c, state: st, events: clone(input.events), exported_at: input.exported_at || null};
  }
  function explicitURLDifferences(candidate) {
    var params = new URLSearchParams(location.search), conflicts = [];
    var fields = {pid: 'pid', sid: 'session_id', order: 'order', mode: 'mode', content_version: 'content_version', study_material_version: 'study_material_version'};
    Object.keys(fields).forEach(function (parameter) {
      if (params.has(parameter) && params.get(parameter) !== String(candidate[fields[parameter]])) conflicts.push(parameter);
    });
    ['d1', 'd2'].forEach(function (p, i) { if (params.has(p) && params.get(p) !== candidate.directions[i]) conflicts.push(p); });
    return conflicts;
  }
  function mergeEvents(original, incoming) {
    var byId = Object.create(null), merged = [];
    original.concat(incoming).forEach(function (event) {
      if (byId[event.event_id]) {
        if (stable(byId[event.event_id]) !== stable(event)) throw new Error('同一 event_id 的内容不同，已停止导入：' + event.event_id);
      } else { byId[event.event_id] = event; merged.push(clone(event)); }
    });
    return merged.sort(function (a, b) { return a.sequence_no - b.sequence_no || a.event_time.localeCompare(b.event_time) || a.event_id.localeCompare(b.event_id); });
  }
  function previewImport(raw) {
    var parsed = validateEnvelope(raw);
    var versionIssue = runtimeVersionIssue(parsed.config);
    if (versionIssue) throw new Error(versionIssue);
    var conflicts = explicitURLDifferences(parsed.config);
    if (conflicts.length) throw new Error('当前链接参数与导入场次冲突：' + conflicts.join('、') + '。请通过不带场次参数的离线页面导入，或使用该场次原链接。');
    var existingRaw = null, existing = null;
    try { existingRaw = localStorage.getItem(PREFIX + parsed.config.session_id); } catch (error) { storageError = '本机存储不可用，恢复后请及时导出。'; }
    if (existingRaw) {
      try { existing = validateEnvelope(JSON.parse(existingRaw)); } catch (error) { throw new Error('本机已存在无法读取的同场次记录，请先导出并核对该记录。'); }
      if (configDifferences(existing.config, parsed.config).length) throw new Error('本机保存的同场次配置与导入文件冲突，已保留原记录。');
      mergeEvents(existing.events, parsed.events);
      if ((existing.state.status === 'withdrawn' || existing.state.status === 'study_complete') && parsed.state.status !== existing.state.status) throw new Error('本机该场次已中止或完成，请核对最新导出文件。');
    }
    importCandidate = {incoming: parsed, existing: existing, existingRaw: existingRaw};
    var stopped = parsed.state.status === 'withdrawn' || parsed.state.status === 'study_complete';
    var options = '<option value="saved">按文件中的断点恢复</option>' + (stopped ? '' : '<option value="1:ai">第一个情境 · 仅 AI 回复</option><option value="1:both">第一个情境 · 已显示医生回复</option><option value="2:ai">第二个情境 · 仅 AI 回复</option><option value="2:both">第二个情境 · 已显示医生回复</option><option value="complete">两情境走查完成</option>');
    var intro = hostControls ? '<p>场次 <strong>' + esc(parsed.config.session_id) + '</strong> · ' + parsed.events.length + ' 条事件</p><p class="muted">保留已有 event_id 和事件，创建新的记录段。以所选断点继续。</p>' : '<p>载入后将继续文件中保存的演示，已有记录会保留。</p>';
    showModal(hostControls ? '恢复场次断点' : '载入已有演示记录', intro + '<label class="field">恢复位置<select name="breakpoint">' + options + '</select></label>' + textarea('reason', '切换原因', '例如：在线页面切换至离线文件') + textarea('missing', '缺失范围（如有）', '记录未能恢复的操作或文字'), {confirm: '导入并恢复', onCancel: function () { importCandidate = null; }, onConfirm: completeImport});
  }
  function rewriteURL(c) {
    try {
      var url = new URL(location.href);
      url.searchParams.set('pid', c.pid); url.searchParams.set('sid', c.session_id); url.searchParams.set('order', c.order);
      url.searchParams.set('d1', c.directions[0]); url.searchParams.set('d2', c.directions[1]); url.searchParams.set('mode', c.mode);
      url.searchParams.delete('content_version'); url.searchParams.delete('study_material_version');
      window.history.replaceState(null, '', url.toString());
    } catch (error) { /* File URLs may reject history rewriting. Saved data still uses the imported session key. */ }
  }
  function completeImport(form) {
    if (!importCandidate) return;
    var candidate = importCandidate, incoming = candidate.incoming;
    try {
      var currentRaw = localStorage.getItem(PREFIX + incoming.config.session_id);
      if (currentRaw !== candidate.existingRaw) throw new Error('本场本地记录刚刚发生变化，请重新选择文件导入。');
    } catch (error) {
      if (!storageError) { S.notice(error.message); return; }
    }
    var reason = formValue(form, 'reason'), missing = formValue(form, 'missing'), point = formValue(form, 'breakpoint');
    config = clone(incoming.config);
    state = clone(incoming.state);
    events = mergeEvents(candidate.existing ? candidate.existing.events : [], incoming.events);
    if (candidate.existing) {
      var priorState = candidate.existing.state;
      var checkpointIds = Object.create(null);
      state.checkpoints = priorState.checkpoints.concat(state.checkpoints).filter(function (item) {
        if (checkpointIds[item.checkpoint_id]) return false;
        checkpointIds[item.checkpoint_id] = true;
        return true;
      });
      state.scenarios.forEach(function (item, index) {
        var previous = priorState.scenarios[index];
        item.consultation_ended = item.consultation_ended || previous.consultation_ended;
        item.initial_understanding_exposed = item.initial_understanding_exposed || previous.initial_understanding_exposed;
        ['started_at', 'ai_revealed_at', 'doctor_revealed_at', 'consultation_ended_at', 'completed_at'].forEach(function (name) {
          var times = [item[name], previous[name]].filter(Boolean).sort();
          item[name] = times[0] || null;
        });
        var marks = Object.create(null);
        item.accidental_reveals = previous.accidental_reveals.concat(item.accidental_reveals).filter(function (mark) {
          var fingerprint = stable(mark);
          if (marks[fingerprint]) return false;
          marks[fingerprint] = true;
          return true;
        });
        var choices = [item.first_choice, previous.first_choice].filter(Boolean).sort(function (a, b) { return a.event_time.localeCompare(b.event_time); });
        item.first_choice = choices[0] || null;
      });
    }
    var originSegment = state.segment_id;
    var originPoint = {scenario_index: state.scenario_index, phase: state.phase, status: state.status};
    var allSegments = (candidate.existing ? candidate.existing.state.segments : []).concat(state.segments), known = Object.create(null);
    state.segments = allSegments.filter(function (segment) { if (known[segment.segment_id]) return false; known[segment.segment_id] = true; return true; });
    state.segment_id = S.uid('segment');
    state.segments.push({segment_id: state.segment_id, started_at: now(), environment: localMode(), reason: reason, imported_from_segment: originSegment, imported_exported_at: incoming.exported_at, imported_breakpoint: originPoint, missing_range: missing});
    if (point !== 'saved') {
      if (point === 'complete') setPhase('walkthrough_complete', 2, 'complete');
      else { var parts = point.split(':'); setPhase('active', Number(parts[0]), parts[1]); }
    }
    state.handoff = null;
    state.last_export = null;
    storageVersion = candidate.existingRaw;
    cleared = false;
    block = null;
    record('segment_started', 'import', reason, {previous_segment_id: originSegment, imported_breakpoint: originPoint, restored_breakpoint: {scenario_index: state.scenario_index, phase: state.phase, status: state.status}, missing_range: missing, source_file_exported_at: incoming.exported_at});
    checkpoint('import_restored');
    importCandidate = null;
    closeModal(false);
    rewriteURL(config);
    requested = clone(config);
    restoredNotice = state.viewport ? '已恢复到刚才的位置' : '已恢复到刚才的阶段';
    persist();
    render();
    S.notice('已恢复场次并建立新的记录段。');
  }
  function recoverSaved() {
    if (!block || !block.saved) return;
    if (runtimeVersionIssue(block.saved.config)) { S.notice(runtimeVersionIssue(block.saved.config)); return; }
    var saved = block.saved;
    config = normalizeConfig(saved.config); state = saved.state; events = saved.events;
    requested = clone(config);
    block = null;
    rewriteURL(config);
    record('session_restored', 'saved_configuration', '', {restore_reason: 'explicitly_selected_saved_configuration'});
    restoredNotice = state.viewport ? '已恢复到刚才的位置' : '已恢复到刚才的阶段';
    persist();
    render();
  }
  function controls() {
    if (!hostControls) return '';
    var h = state.handoff;
    return '<details class="panel participant-controls" id="participant-controls"' + (controlsOpen ? ' open' : '') + '><summary>研究者控制与记录管理</summary><div class="participant-control-body"><p class="muted">场次 ' + esc(config.session_id) + ' · ' + esc(config.pid) + ' · ' + esc(config.order) + ' · ' + esc(config.directions.join(' / ')) + '</p><p class="muted">' + esc(config.study_material_version) + ' / ' + esc(config.content_version) + '<br>记录段 ' + esc(state.segment_id) + ' · 已记录 ' + events.length + ' 个事件</p><div class="toolbar">' + button('accidental', '标记提前接触医生回复', 'secondary', !isActive()) + button('handoff', '确认记录已交回', 'secondary', !!block) + button('finish-study', '记录整场研究完成', 'secondary', !!block || state.status !== 'walkthrough_complete') + '</div><div class="toolbar">' + button('supplement', '记录补充材料展示', 'secondary', !!block || state.status !== 'walkthrough_complete') + button('design', '记录设计阶段开始', 'secondary', !!block || state.status !== 'walkthrough_complete') + '</div><label class="field">导入本场 JSON / 切换至离线断点<input id="participant-import" type="file" accept=".json,application/json"></label>' + (h ? '<p class="participant-delivery">交回确认：' + esc(h.result === 'complete' ? '已核对完整' : '有缺失／待补') + ' · ' + esc(h.confirmed_at) + '<br>' + esc(h.filename) + '</p>' : '') + '<p class="muted">日志在此设备保存，导出后按已确认渠道交回。共享研究画面时收起本区。</p></div></details>';
  }
  function secondaryMenu() {
    if (cleared) return '';
    var offlineImport = localMode() === 'offline' && !hostControls ? '<label class="field">载入已有演示记录<input id="participant-import" type="file" accept=".json,application/json"></label>' : '';
    var items = (exportEnabled ? button('export', '导出当前记录') + button('clear', '清除本场记录', 'danger') : '') + (!isStopped() && !block ? button('withdraw', '退出本场研究') : '') + offlineImport + controls();
    return items ? '<details class="participant-menu"' + (menuOpen ? ' open' : '') + '><summary aria-label="更多操作">更多</summary><div class="participant-menu-items">' + items + '</div></details>' : '';
  }
  function render() {
    if (!config || !state) return;
    var header = '<header class="participant-heading"><h1>' + esc(textUI('consultation_title', '模拟问诊演示')) + '</h1>' + secondaryMenu() + '</header>';
    var reviewNote = config.mode === 'preview' ? '<p class="participant-preview badge">研究者内部预览 · ' + (clinicalReady() ? '临床审核记录已配置' : '临床内容待审核') + '</p>' : '';
    var body = '';
    if (cleared) {
      app.innerHTML = '<main class="page-shell participant-shell">' + header + '<section class="panel"><h2>本场记录已清除</h2><p>当前浏览器中的 ' + esc(config.session_id) + ' 记录已删除。</p><p class="muted">请按约定处理下载文件及其他设备上的副本。</p></section></main>';
      return;
    }
    if (block) {
      body = '<section class="panel participant-state"><h2>场次需要核对</h2><p>' + esc(block.message) + '</p>' + (block.differences ? '<p class="muted">冲突字段：' + esc(block.differences.join('、')) + '</p>' : '') + (block.saved && !runtimeVersionIssue(block.saved.config) ? button('recover-saved', '按已保存配置继续') : '') + '</section>';
    } else if (!canRun()) {
      body = '<section class="panel participant-state"><h2>正式研究暂未开放</h2><p>' + esc(runtimeVersionIssue(config) || '本版本的临床内容尚未审核通过。请待审核记录与正式材料配置完成后开始。') + '</p></section>';
    } else if (state.status === 'ready') {
      body = '<section id="participant-scene" class="panel participant-intro">' + button('start', textUI('start', '开始'), 'primary') + '</section>';
    } else if (state.status === 'active') {
      body = '<section id="participant-scene" class="participant-scene">' + (state.scenario_index === 2 ? '<p class="muted" style="text-align:center">接下来是另一个独立的模拟问诊。</p>' : '') + '<div class="phone-wrap">' + S.renderPhone({caseId: scenario().caseId, identity: scenario().identity, direction: scenario().direction, phase: state.phase, mode: 'conflict', blocks: [], consultationEnded: history().consultation_ended}) + '</div><div class="participant-progression panel">' + (state.phase === 'ai' ? button('reveal', textUI('reveal', '查看医生回复'), 'primary') : button('next', state.scenario_index === 1 ? textUI('next', '进入下一个问诊') : '完成问诊演示', 'primary')) + '</div></section>';
    } else if (state.status === 'withdrawn') {
      body = '<section id="participant-scene" class="panel participant-state"><h2>本场研究已中止</h2><p>请与主持人完成已有记录的处理。</p></section>';
    } else {
      body = '<section id="participant-scene" class="panel participant-state"><div class="participant-intro-mark" aria-hidden="true">✓</div><h2>' + (state.status === 'study_complete' ? '本场研究已完成' : '演示结束，请回到访谈') + '</h2><p>' + (state.status === 'study_complete' ? '感谢参与。请按主持人的安排完成记录交回和核对。' : (storageError || block ? '本机保存未成功，请由主持人核对并导出备份。' : '本机检查点已保存成功。请继续与主持人交流。')) + '</p></section>';
    }
    app.innerHTML = '<main class="page-shell participant-shell">' + header + reviewNote + (storageError ? '<p role="alert" class="participant-storage-alert">' + esc(storageError) + '</p>' : '') + '<div class="participant-recovery-status" role="status">' + esc(restoredNotice) + '</div>' + body + '</main>';
    var details = document.getElementById('participant-controls');
    if (details) details.addEventListener('toggle', function () { controlsOpen = details.open; });
    var menu = app.querySelector('.participant-menu');
    if (menu) menu.addEventListener('toggle', function () { menuOpen = menu.open; });
    S.bindPhoneInteractions(app);
    var phone = app.querySelector('.study-phone');
    if (phone) phone.addEventListener('scroll', scheduleViewportSave, {passive: true});
    requestAnimationFrame(restoreViewport);
  }
  function initialize() {
    try {
      requested = normalizeConfig(S.parseConfig());
      config = clone(requested);
      state = makeState();
      var raw;
      try { raw = localStorage.getItem(key()); storageVersion = raw; } catch (error) { storageError = '浏览器未能读取本地记录。请使用已验证的普通浏览模式，并及时导出。'; }
      if (raw) {
        var saved;
        try { saved = validateEnvelope(JSON.parse(raw)); } catch (error) {
          block = {type: 'invalid_saved', message: '本机记录暂时无法恢复：' + error.message, raw: raw};
          events = [];
          render();
          return;
        }
        var differences = configDifferences(saved.config, requested);
        config = saved.config; state = saved.state; events = saved.events;
        if (differences.length) {
          block = {type: 'configuration', message: '链接参数或材料版本与本机已保存的场次配置不同，现有记录已保留。', differences: differences, saved: saved};
        } else if (runtimeVersionIssue(config)) {
          block = {type: 'version', message: runtimeVersionIssue(config), saved: saved};
        } else {
          record('session_restored', 'refresh', '', {restored_status: state.status, restored_phase: state.phase});
          restoredNotice = state.viewport ? '已恢复到刚才的位置' : '已恢复到刚才的阶段';
          persist();
        }
      } else { persist(); }
      render();
    } catch (error) {
      app.innerHTML = '<main class="page-shell"><section class="panel"><h1>无法载入场次</h1><p>' + esc(error.message) + '</p><p class="muted">请由主持人核对场次链接。</p></section></main>';
    }
  }



  app.addEventListener('click', function (event) {
    var control = event.target.closest('[data-control]');
    if (control && !control.disabled) {
      var action = control.getAttribute('data-control');
      if (!hostControls && HOST_ACTIONS.indexOf(action) !== -1) return;
      var handlers = {start: start, reveal: reveal, next: next, export: function () { exportLog('manual'); }, accidental: accidental, withdraw: withdraw, handoff: handoff, clear: clearCurrent, 'finish-study': finishStudy, 'recover-saved': recoverSaved, supplement: function () { researcherNote('supplement'); }, design: function () { researcherNote('design'); }};
      if (handlers[action]) handlers[action]();
      return;
    }
    var operation = event.target.closest('[data-action]');
    if (operation && !operation.disabled) openAction(operation.getAttribute('data-action'));
  });
  app.addEventListener('study:phone-jump', function (event) {
    if (!isActive() || state.phase !== 'both') return;
    record('advice_index_selected', event.detail && event.detail.target || 'advice-index');
    captureViewport();
    persist();
  });
  window.addEventListener('scroll', scheduleViewportSave, {passive: true});
  window.addEventListener('pagehide', function () { if (isActive()) { captureViewport(); persist(); } });
  app.addEventListener('change', function (event) {
    if (!hostControls && localMode() !== 'offline') return;
    if (event.target.id !== 'participant-import' || !event.target.files || !event.target.files[0]) return;
    var file = event.target.files[0];
    if (file.size > 15 * 1024 * 1024) { S.notice('文件超过 15 MB，请核对是否为本场 JSON。'); return; }
    file.text().then(function (text) {
      try { previewImport(JSON.parse(text)); } catch (error) { S.notice('导入未完成：' + error.message); }
    }).catch(function () { S.notice('无法读取所选文件，请重新选择。'); });
    event.target.value = '';
  });
  window.addEventListener('storage', function (event) {
    if (!config || cleared || event.key !== key() || event.newValue === storageVersion) return;
    block = {type: 'concurrent', message: event.newValue === null ? '此场次已在另一窗口清除。请关闭此窗口，避免继续记录。' : '此场次已在另一窗口更新。请导出当前窗口记录，再刷新载入最新状态。'};
    closeModal(false);
    render();
  });
  window.StudyParticipant = Object.freeze({snapshot: function () { return state && config && !cleared ? envelope('inspection') : null; }});
  initialize();
}());
