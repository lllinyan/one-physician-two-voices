(function () {
  'use strict';
  const S=window.Study,C=window.StudyContent,app=document.getElementById('app'),E=S.esc;
  const page=document.body.dataset.page,isDisplay=page==='cards-display',isPaper=page==='cards-print';
  const cardSource=C.participation_cards||{},choices=[['yes','是'],['no','否'],['unsure','不确定']],choiceLabels=Object.fromEntries(choices);
  const copy=x=>JSON.parse(JSON.stringify(x)),now=()=>new Date().toISOString();
  let config,avatarScenario,doctor,otherScenario,otherDoctor;
  const validationErrors=[];
  try {
    config=S.parseConfig();
    const scenarios=S.scenarios(config.order);
    const avatarIndex=scenarios.findIndex(s=>s.identity==='avatar');
    avatarScenario={...scenarios[avatarIndex],direction:config.directions[avatarIndex]};
    otherScenario={...scenarios[1-avatarIndex],direction:config.directions[1-avatarIndex]};
    doctor=C.cases[avatarScenario.caseId].doctor;
    otherDoctor=C.cases[otherScenario.caseId].doctor;
  } catch(error){validationErrors.push(error.message);}
  if(cardSource.status!=='approved_text')validationErrors.push('参与程度卡片原文尚待研究者提供和确认。');
  if(!Array.isArray(cardSource.statements)||cardSource.statements.length!==7||cardSource.statements.some(s=>!s||!s.id||typeof s.text!=='string'||!s.text.trim())||new Set((cardSource.statements||[]).map(s=>s?.id)).size!==7)validationErrors.push('需提供固定顺序的七句陈述原文。');
  if(!Array.isArray(cardSource.rounds)||cardSource.rounds.length!==3||cardSource.rounds.some(r=>!r||!r.id||typeof r.prompt!=='string'||!r.prompt.trim())||new Set((cardSource.rounds||[]).map(r=>r?.id)).size!==3)validationErrors.push('需提供三轮提问原文。');
  if(typeof cardSource.comparison_prompt!=='string'||!cardSource.comparison_prompt.trim())validationErrors.push('需提供最后对照步骤的提问原文。');
  if(config?.mode==='study'&&(C.clinical_review_status?.status!=='approved'||!C.clinical_review_status?.record_id||Object.values(C.cases).some(c=>c.clinical_review_status!=='approved')))validationErrors.push('临床审核尚未完成，正式研究模式无法启动。');
  const ready=!validationErrors.length,statements=ready?cardSource.statements:[],rounds=ready?cardSource.rounds:[];
  const sourceSignature=JSON.stringify({statements,rounds,comparison_prompt:cardSource.comparison_prompt||'',status:cardSource.status});
  const configSignature=JSON.stringify(config?{pid:config.pid,session_id:config.session_id,order:config.order,directions:config.directions,mode:config.mode,study_material_version:config.study_material_version,content_version:config.content_version}:null);
  const storageKey='one-physician:cards:'+(config?.session_id||'INVALID'),leaseKey=storageKey+':controller';
  const controllerId=S.uid('cards_controller'),channelName=storageKey+':channel';
  let state,channel=null,storageWarning='',readOnly=false,publicSnapshot=null,lastContact=0,heartbeat,disconnectTimer,leaseTimer;
  let resultOverlay=null,paperIdentity='avatar';
  const optionName=value=>choiceLabels[value]||'—';
  function eventRecord(type,target='',data={}) {
    const comparison=state.phase==='comparison',context=comparison?otherScenario:avatarScenario,currentDoctor=comparison?otherDoctor:doctor;
    const event={event_id:S.uid('card_event'),session_id:config.session_id,pid:config.pid,segment_id:state.segment_id,sequence_no:state.events.length+1,order:config.order,case_id:context.caseId,doctor_id:currentDoctor.id,identity:context.identity,direction:context.direction,phase:state.phase==='round'?'card_round':state.phase,source:'card_elicitation',event_time:now(),event_type:type,target,round_index:state.phase==='round'?state.round_index+1:null,round_id:state.phase==='round'?rounds[state.round_index].id:null,study_material_version:config.study_material_version,content_version:config.content_version,...data};
    state.events.push(event);state.updated_at=event.event_time;return event;
  }
  function freshState() {
    return {schema_version:'1.0',kind:'card_elicitation',source:'card_elicitation',config:copy(config),source_signature:sourceSignature,segment_id:S.uid('card_segment'),phase:'ready',round_index:0,answers:[{},{},{}],comparison:{selected:[],submitted:false,submitted_at:null,skipped:false,skipped_at:null},events:[],created_at:now(),updated_at:now(),revision:0};
  }
  function validSaved(saved) {
    if(!saved||saved.kind!=='card_elicitation'||saved.schema_version!=='1.0'||JSON.stringify(saved.config)!==JSON.stringify(config)||saved.source_signature!==sourceSignature)throw Error('该场已有记录的配置或卡片原文不同，请先核对原记录。');
    if(!['ready','round','waiting_design','waiting_comparison','comparison','complete'].includes(saved.phase)||!Number.isInteger(saved.round_index)||saved.round_index<0||saved.round_index>2||!Array.isArray(saved.answers)||saved.answers.length!==3||!Array.isArray(saved.events)||!saved.comparison||!Array.isArray(saved.comparison.selected))throw Error('已有卡片记录格式不符，请保留原文件核对。');
    const ids=new Set(statements.map(s=>s.id));
    for(const answers of saved.answers)for(const [key,value]of Object.entries(answers))if(!ids.has(key)||!choiceLabels[value])throw Error('已有卡片回答超出当前材料范围。');
    if(saved.comparison.selected.some(id=>!ids.has(id)))throw Error('已有对照记录超出当前材料范围。');
    return saved;
  }
  function persist() {
    if(isDisplay||isPaper||!state||!ensureOwnership())return false;
    try {localStorage.setItem(storageKey,JSON.stringify(state));storageWarning='';return true;}
    catch(error){storageWarning='本机保存失败，请导出 JSON 保留本场记录。';return false;}
  }
  function ownsLease(allowExpired=false) {
    try {const lease=JSON.parse(localStorage.getItem(leaseKey)||'null');return !lease||lease.id===controllerId||(allowExpired&&Date.now()-lease.updated>8000);}catch(_){return true;}
  }
  function ensureOwnership() {
    if(readOnly)return false;
    if(ownsLease())return true;
    readOnly=true;storageWarning='另一研究者窗口已接管本场，请使用该窗口继续。';
    clearInterval(heartbeat);clearInterval(leaseTimer);render();return false;
  }
  function claimLease() {
    if(!ownsLease(true)){readOnly=true;storageWarning='此场次已在另一个研究者窗口打开，请使用原窗口继续。';return false;}
    try {localStorage.setItem(leaseKey,JSON.stringify({id:controllerId,updated:Date.now()}));}catch(_){storageWarning='浏览器未提供本地保存，结束前请导出 JSON。';}
    return true;
  }
  function phaseToken(){return state.phase+':'+state.round_index;}
  function publicState() {
    if(!state)return null;
    const current=state.phase==='round'?copy(state.answers[state.round_index]):{};
    const currentDoctor=state.phase==='comparison'?otherDoctor:doctor;
    return {type:'cards_snapshot',source_signature:sourceSignature,config_signature:configSignature,phase:state.phase,phase_token:phaseToken(),revision:state.revision,controller_id:controllerId,sent_at:Date.now(),prompt:state.phase==='round'?S.tpl(rounds[state.round_index].prompt,doctor):state.phase==='comparison'?S.tpl(cardSource.comparison_prompt,otherDoctor):'',statements:statements.map(s=>({id:s.id,text:S.tpl(s.text,currentDoctor)})),answers:current,comparison:state.phase==='comparison'?{selected:[...state.comparison.selected]}:null};
  }
  function broadcast() {
    if(!channel||isDisplay||isPaper||!ready||!ensureOwnership())return;
    try {channel.postMessage(publicState());}catch(_){storageWarning='本地展示连接不可用，请在研究者窗口查看。';}
  }
  function dispatch(action,payload={},origin='controller') {
    if(!ready||!state||isDisplay||isPaper||!ensureOwnership())return false;
    if(origin==='display'&&!['answer','next','skip-unanswered','compare','finish','skip-comparison'].includes(action))return false;
    if(payload.phase_token&&payload.phase_token!==phaseToken()){broadcast();return false;}
    const previousPhase=phaseToken();
    if(action==='start'){
      if(state.phase!=='ready')return false;
      state.phase='round';state.round_index=0;eventRecord('cards_started',rounds[0].id);
    }else if(action==='answer'){
      if(state.phase!=='round'||!statements.some(s=>s.id===payload.id)||!choiceLabels[payload.value])return false;
      const previous=state.answers[state.round_index][payload.id]||null;
      if(previous===payload.value)return true;
      state.answers[state.round_index][payload.id]=payload.value;
      eventRecord('card_response',payload.id,{value:payload.value,previous_value:previous});
    }else if(action==='next'||action==='skip-unanswered'){
      if(state.phase!=='round')return false;
      const unanswered=statements.filter(s=>!state.answers[state.round_index][s.id]).map(s=>s.id);
      if(unanswered.length&&action!=='skip-unanswered'){S.notice('请作出选择，或点击“跳过未答并继续”。');return false;}
      if(unanswered.length)eventRecord('card_round_skipped_unanswered',rounds[state.round_index].id,{unanswered_ids:unanswered});
      eventRecord('card_round_completed',rounds[state.round_index].id,{answers:copy(state.answers[state.round_index]),unanswered_ids:unanswered,completion_method:action});
      if(state.round_index===0){state.round_index=1;eventRecord('card_round_started',rounds[1].id);}
      else if(state.round_index===1){state.phase='waiting_design';eventRecord('cards_waiting_for_design','researcher_gate');}
      else {state.phase='waiting_comparison';eventRecord('cards_waiting_for_comparison','researcher_gate');}
    }else if(action==='open-round-three'){
      if(state.phase!=='waiting_design')return false;
      state.phase='round';state.round_index=2;eventRecord('card_round_started',rounds[2].id,{opened_by:'researcher',after_design:true});
    }else if(action==='skip-round-three'){
      if(state.phase!=='waiting_design')return false;
      const reason=typeof payload.reason==='string'?payload.reason.trim():'';
      if(!reason){S.notice('请记录未形成或未确认方案的原因。');return false;}
      eventRecord('card_round_skipped',rounds[2].id,{round_index:3,round_id:rounds[2].id,reason,unanswered_ids:statements.map(s=>s.id),opened_by:'researcher',prompt_shown:false});
      state.round_index=2;state.phase='waiting_comparison';eventRecord('cards_waiting_for_comparison','researcher_gate');
    }else if(action==='open-comparison'){
      if(state.phase!=='waiting_comparison')return false;
      state.phase='comparison';eventRecord('card_comparison_started','general_ai',{comparison_case_id:otherScenario.caseId,comparison_identity:otherScenario.identity,opened_by:'researcher'});
    }else if(action==='compare'){
      if(state.phase!=='comparison'||!statements.some(s=>s.id===payload.id)||typeof payload.selected!=='boolean')return false;
      const selected=new Set(state.comparison.selected);payload.selected?selected.add(payload.id):selected.delete(payload.id);
      state.comparison.selected=statements.filter(s=>selected.has(s.id)).map(s=>s.id);
      eventRecord('card_comparison_changed',payload.id,{selected:payload.selected});
    }else if(action==='skip-comparison'){
      if(state.phase!=='comparison')return false;
      state.comparison.skipped=true;state.comparison.skipped_at=now();
      eventRecord('card_comparison_skipped','general_ai',{partial_selected:[...state.comparison.selected],comparison_case_id:otherScenario.caseId});
      state.phase='complete';eventRecord('cards_completed','card_elicitation');
    }else if(action==='finish'){
      if(state.phase!=='comparison')return false;
      state.comparison.submitted=true;state.comparison.submitted_at=now();
      eventRecord('card_comparison_submitted','general_ai',{selected:[...state.comparison.selected],explicit_empty:state.comparison.selected.length===0,comparison_case_id:otherScenario.caseId});
      state.phase='complete';eventRecord('cards_completed','card_elicitation');
    }else return false;
    state.revision++;persist();render();if(previousPhase!==phaseToken())focusQuestion();broadcast();return true;
  }
  function sendCommand(action,payload={}) {
    if(!isDisplay){dispatch(action,payload);return;}
    if(!publicSnapshot||Date.now()-lastContact>4500||!channel)return;
    if(action==='next'&&publicSnapshot.phase==='round'&&publicSnapshot.statements.some(s=>!publicSnapshot.answers[s.id])){S.notice('请作出选择，或点击“跳过未答并继续”。');return;}
    channel.postMessage({type:'cards_command',source_signature:sourceSignature,config_signature:configSignature,controller_id:publicSnapshot.controller_id,action,payload:{...payload,phase_token:publicSnapshot.phase_token}});
  }
  function gateHTML() {
    return '<section class="panel cards-gate"><h2>材料待提供原文</h2><ul>'+validationErrors.map(t=>'<li>'+E(t)+'</li>').join('')+'</ul><button class="btn primary" disabled>开始</button> <button class="btn" disabled>打印卡片</button></section>';
  }
  function previewNotice(){return config?.mode==='preview'?'<p class="cards-preview-note">内部预览版'+(C.clinical_review_status?.status!=='approved'?' · 临床内容待审核':'')+'</p>':'';}
  function questionHTML(snapshot,interactive=true) {
    if(!snapshot||snapshot.phase==='ready')return '<section class="panel cards-wait"><h2>等待开始</h2></section>';
    if(['waiting_design','waiting_comparison'].includes(snapshot.phase))return '<section class="panel cards-wait"><h2>请回到访谈</h2></section>';
    if(snapshot.phase==='complete')return '<section class="panel cards-wait"><h2>本环节已完成</h2><p>请回到访谈。</p></section>';
    const isRound=snapshot.phase==='round';
    return '<section class="cards-question"><h2 tabindex="-1">'+E(snapshot.prompt)+'</h2><div class="cards-statements">'+snapshot.statements.map(s=>'<fieldset class="card-statement"><legend>'+E(s.text)+'</legend>'+(isRound?'<div class="card-choices">'+choices.map(([value,label])=>'<label class="card-choice"><input type="radio" name="card-'+E(s.id)+'" value="'+value+'" data-card-answer="'+E(s.id)+'"'+(snapshot.answers[s.id]===value?' checked':'')+(!interactive?' disabled':'')+'><span>'+label+'</span></label>').join('')+'</div>':'<label class="card-compare"><input type="checkbox" data-card-compare="'+E(s.id)+'"'+(snapshot.comparison.selected.includes(s.id)?' checked':'')+(!interactive?' disabled':'')+'><span>选择这句</span></label>')+'</fieldset>').join('')+'</div><div class="cards-step-actions toolbar"><button class="btn primary" data-cards-action="'+(isRound?'next':'finish')+'"'+(!interactive?' disabled':'')+'>'+(isRound?'继续':'提交选择')+'</button><button class="btn secondary" data-cards-action="'+(isRound?'skip-unanswered':'skip-comparison')+'"'+(!interactive?' disabled':'')+'>'+(isRound?'跳过未答并继续':'跳过本步')+'</button></div></section>';
  }
  function answerTable(printing=false) {
    return '<table class="cards-result-table"><caption>三轮回答（'+E(doctor.name)+'）与对照结果（'+E(otherDoctor.name)+'）</caption><thead><tr><th scope="col">陈述</th>'+rounds.map((r,i)=>'<th scope="col">第 '+(i+1)+' 轮</th>').join('')+'<th scope="col">通用 AI 对照<br>陈述中的医生：'+E(otherDoctor.name)+'</th></tr></thead><tbody>'+statements.map(s=>'<tr><th scope="row">'+E(S.tpl(s.text,doctor))+'</th>'+state.answers.map((a,i)=>{const changed=i>0&&a[s.id]&&state.answers[i-1][s.id]&&a[s.id]!==state.answers[i-1][s.id];return '<td'+(changed?' class="cards-answer-changed"':'')+'>'+optionName(a[s.id])+(changed?' <span>变化</span>':'')+'</td>';}).join('')+'<td>'+(state.comparison.submitted?(state.comparison.selected.includes(s.id)?'已选':'未选'):state.comparison.skipped?'已跳过':'未提交')+'</td></tr>').join('')+'</tbody></table>';
  }
  function documentLinks(){const printURL=new URL('print.html',location.href);printURL.search=location.search;return '<a class="btn" href="'+E(printURL.href)+'" target="_blank" rel="noopener">纸质卡片</a>';}
  function rememberedFocus() {
    const active=document.activeElement;
    if(!active?.getAttribute)return null;
    for(const attr of ['data-card-answer','data-card-compare','data-cards-action']){
      const id=active.getAttribute(attr);
      if(id!==null)return {attr,id,value:active.value};
    }
    return null;
  }
  function restoreFocus(saved) {
    if(!saved)return;
    const element=Array.from(app.querySelectorAll?.('['+saved.attr+']')||[]).find(el=>el.getAttribute(saved.attr)===saved.id&&(saved.attr!=='data-card-answer'||el.value===saved.value));
    element?.focus?.({preventScroll:true});
  }
  function focusQuestion() {
    const heading=app.querySelector?.('.cards-question>h2');
    heading?.focus?.();
    if(isDisplay&&typeof window.scrollTo==='function')window.scrollTo({top:0,behavior:'auto'});
  }
  function render() {
    const savedFocus=rememberedFocus();
    if(isPaper){renderPaper();return;}
    if(isDisplay){
      document.title='参与程度卡片';
      const connected=ready&&publicSnapshot&&Date.now()-lastContact<=4500;
      app.innerHTML='<main class="cards-display">'+previewNotice()+(ready?'<p class="cards-connection" role="status">'+(connected?'已连接':'预览暂停')+'</p>'+(connected?questionHTML(publicSnapshot):'<section class="panel cards-wait"><p>等待研究者窗口连接。</p></section>'):gateHTML())+'</main>';
      restoreFocus(savedFocus);return;
    }
    document.title='研究者操作 · 参与程度卡片';
    const blocked=!ready||readOnly;
    app.innerHTML='<main class="page-shell cards-host"><header class="cards-host-head"><div><p class="eyebrow">研究者操作</p><h1>参与程度卡片</h1><p class="muted">'+(config?E(config.pid)+' · '+E(config.session_id):'配置无效')+'</p></div><div class="toolbar"><button class="btn primary" data-cards-action="open-display"'+(blocked?' disabled':'')+'>打开展示窗口</button><button class="btn" data-cards-action="export"'+(blocked?' disabled':'')+'>导出 JSON</button><button class="btn" data-cards-action="print-results"'+(blocked||state?.phase!=='complete'?' disabled':'')+'>打印结果表</button>'+(ready?documentLinks():'<button class="btn" disabled>纸质卡片</button>')+'</div></header>'+previewNotice()+(storageWarning?'<p class="cards-storage-warning" role="status">'+E(storageWarning)+'</p>':'')+(!ready?gateHTML():'<div class="cards-host-grid"><section class="panel"><h2>当前呈现</h2><p class="muted">分身情境：'+E(doctor.name)+'。展示窗口只呈现当前步骤；共创后的第三轮与收尾对照由研究者开放。</p>'+(state.phase==='ready'?'<button class="btn primary" data-cards-action="start"'+(readOnly?' disabled':'')+'>开始</button>':questionHTML(publicState(),!readOnly))+(state.phase==='waiting_design'?'<button class="btn primary" data-cards-action="open-round-three"'+(readOnly?' disabled':'')+'>共创完成，进入第三轮</button><label for="cards-skip-third-reason">未形成或未确认方案时，请记录跳过原因</label><textarea id="cards-skip-third-reason" rows="2" maxlength="1000"'+(readOnly?' disabled':'')+'></textarea><button class="btn secondary" data-cards-action="skip-round-three"'+(readOnly?' disabled':'')+'>跳过第三轮（未形成或未确认方案）</button>':state.phase==='waiting_comparison'?'<button class="btn primary" data-cards-action="open-comparison"'+(readOnly?' disabled':'')+'>收尾时开放通用 AI 对照</button>':'')+'<p class="cards-save-status" role="status">'+(storageWarning?'请保留导出文件':'本场记录已保存在本机')+'</p></section><section class="panel cards-host-results"><h2>研究者对照</h2>'+answerTable()+'<details><summary>本场三轮提问</summary><ol>'+rounds.map(r=>'<li>'+E(S.tpl(r.prompt,doctor))+'</li>').join('')+'</ol><p>'+E(S.tpl(cardSource.comparison_prompt,otherDoctor))+'</p></details><p class="muted">'+state.events.length+' 条事件 · 变化标记比较相邻两轮回答。</p></section></div>')+'</main>';
    restoreFocus(savedFocus);
  }
  function renderPaper() {
    document.title='参与程度纸质卡片';
    const paperDoctor=paperIdentity==='general'?otherDoctor:doctor;
    app.innerHTML='<main class="cards-paper">'+(!ready?gateHTML():'<header class="cards-paper-controls"><h1>参与程度纸质卡片</h1><p>当前纸卡：'+(paperIdentity==='general'?'通用医疗 AI 情境':'分身情境')+' · '+E(paperDoctor.name)+' · A4 纵向，沿虚线裁切。</p><div class="toolbar"><button class="btn" data-cards-action="paper-avatar" aria-pressed="'+(paperIdentity==='avatar')+'">分身情境</button><button class="btn" data-cards-action="paper-general" aria-pressed="'+(paperIdentity==='general')+'">通用 AI 情境</button></div><button class="btn primary" data-cards-action="print-paper">打印／保存 PDF</button></header><section class="cards-paper-grid">'+statements.map(s=>'<article class="cards-paper-card"><p>'+E(S.tpl(s.text,paperDoctor))+'</p></article>').join('')+choices.map(([,label])=>'<article class="cards-paper-card cards-category"><strong>'+label+'</strong></article>').join('')+'</section>')+'</main>';
  }
  function exportData() {
    if(!state||!ready||!ensureOwnership())return false;
    eventRecord('cards_exported','json');persist();
    const exported={...copy(state),exported_at:now(),stimuli:{statements:statements.map(s=>({...s,text:S.tpl(s.text,doctor)})),rounds:rounds.map(r=>({...r,prompt:S.tpl(r.prompt,doctor)})),comparison_prompt:S.tpl(cardSource.comparison_prompt,otherDoctor)},comparison_stimuli:{doctor:copy(otherDoctor),case_id:otherScenario.caseId,identity:'general',direction:otherScenario.direction,statements:statements.map(s=>({...s,text:S.tpl(s.text,otherDoctor)})),prompt:S.tpl(cardSource.comparison_prompt,otherDoctor)}};
    S.download(config.session_id+'_cards.json',exported);render();return exported;
  }
  function showResultPrint() {
    if(!state||state.phase!=='complete'||!ready)return;
    if(resultOverlay)resultOverlay.remove();
    const previousTitle=document.title,previousFocus=document.activeElement;
    resultOverlay=document.createElement('section');resultOverlay.id='cards-result-print';resultOverlay.className='cards-result-print';resultOverlay.setAttribute('role','dialog');resultOverlay.setAttribute('aria-modal','true');resultOverlay.setAttribute('aria-label','卡片结果打印预览');
    resultOverlay.innerHTML='<header class="cards-result-controls"><button class="btn primary" data-result-print>打印／保存 PDF</button> <button class="btn" data-result-close>返回</button></header><article class="cards-result-sheet"><h1>参与程度卡片结果</h1><p class="cards-result-meta">场次：'+E(config.session_id)+' · 接诊医生：'+E(doctor.name)+' · 来源：卡片引出</p>'+answerTable(true)+'<div class="cards-result-prompts">'+rounds.map((r,i)=>'<p>第 '+(i+1)+' 轮：'+E(S.tpl(r.prompt,doctor))+'</p>').join('')+'<p>对照：'+E(S.tpl(cardSource.comparison_prompt,otherDoctor))+'</p></div><p>'+(state.comparison.skipped?'对照已跳过，未回答保留缺失。':'对照已提交'+(state.comparison.selected.length?'，选中 '+state.comparison.selected.length+' 句。':'，明确未选择任何陈述。'))+'</p></article>';
    const close=()=>{resultOverlay.remove();resultOverlay=null;document.body.classList.remove('cards-printing-results');document.title=previousTitle;previousFocus?.focus?.();};
    resultOverlay.querySelector('[data-result-close]').onclick=close;resultOverlay.querySelector('[data-result-print]').onclick=()=>window.print();
    resultOverlay.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();close();}if(ev.key==='Tab'){const buttons=resultOverlay.querySelectorAll('button');if(ev.shiftKey&&document.activeElement===buttons[0]){ev.preventDefault();buttons[1].focus();}else if(!ev.shiftKey&&document.activeElement===buttons[1]){ev.preventDefault();buttons[0].focus();}}});
    document.body.append(resultOverlay);document.body.classList.add('cards-printing-results');document.title=config.session_id+'_cards_result';resultOverlay.querySelector('[data-result-print]').focus();
  }
  function setupChannel() {
    if(!ready||isPaper||typeof BroadcastChannel!=='function')return;
    channel=new BroadcastChannel(channelName);
    channel.onmessage=ev=>{
      const data=ev.data;
      if(!data||data.source_signature!==sourceSignature||data.config_signature!==configSignature)return;
      if(isDisplay){
        if(data.type==='cards_paused'){if(!publicSnapshot||data.controller_id===publicSnapshot.controller_id){publicSnapshot=null;lastContact=0;render();}return;}
        if(data.type!=='cards_snapshot')return;
        if(publicSnapshot&&publicSnapshot.controller_id===data.controller_id&&data.revision<publicSnapshot.revision)return;
        const changed=!publicSnapshot||publicSnapshot.revision!==data.revision||publicSnapshot.controller_id!==data.controller_id;
        const newPhase=!publicSnapshot||publicSnapshot.phase_token!==data.phase_token;
        publicSnapshot=data;lastContact=Date.now();if(changed)render();if(newPhase)focusQuestion();
      }else if(!readOnly){
        if(data.type==='cards_hello')broadcast();
        else if(data.type==='cards_command'&&data.controller_id===controllerId)dispatch(data.action,data.payload||{},'display');
      }
    };
    if(isDisplay){
      channel.postMessage({type:'cards_hello',source_signature:sourceSignature,config_signature:configSignature});
      disconnectTimer=setInterval(()=>{if(publicSnapshot&&Date.now()-lastContact>4500){publicSnapshot=null;render();}},1000);
    }else if(!readOnly)heartbeat=setInterval(broadcast,1000);
  }
  app.addEventListener('click',ev=>{
    const button=ev.target.closest?.('[data-cards-action]');if(!button||button.disabled)return;
    const action=button.getAttribute('data-cards-action');
    if(isPaper&&ready&&['paper-avatar','paper-general'].includes(action)){paperIdentity=action==='paper-general'?'general':'avatar';renderPaper();return;}
    if(action==='print-paper'){window.print();return;}
    if(!isDisplay&&ready&&!ensureOwnership())return;
    if(action==='open-display'){
      const url=new URL('display.html',location.href);url.search=location.search;
      window.open(url.href,'cards_'+config.session_id);eventRecord('cards_display_opened','display');persist();broadcast();return;
    }
    if(action==='export'){exportData();return;}
    if(action==='print-results'){showResultPrint();return;}
    if(action==='skip-round-three'){sendCommand(action,{reason:document.getElementById('cards-skip-third-reason')?.value||''});return;}
    sendCommand(action);
  });
  app.addEventListener('change',ev=>{
    const target=ev.target;
    if(target.hasAttribute?.('data-card-answer'))sendCommand('answer',{id:target.getAttribute('data-card-answer'),value:target.value});
    else if(target.hasAttribute?.('data-card-compare'))sendCommand('compare',{id:target.getAttribute('data-card-compare'),selected:target.checked});
  });
  if(ready&&!isDisplay&&!isPaper){
    state=freshState();
    try {const raw=localStorage.getItem(storageKey);if(raw){state=validSaved(JSON.parse(raw));}}catch(error){readOnly=true;storageWarning=error.message;}
    if(!readOnly&&claimLease()){
      if(state.events.length)eventRecord('cards_restored','local_storage');persist();
      leaseTimer=setInterval(()=>{if(ensureOwnership())claimLease();},2000);
    }
  }
  setupChannel();render();
  if(!isDisplay&&!isPaper&&ready&&!readOnly)broadcast();
  window.addEventListener('pagehide',()=>{
    clearInterval(heartbeat);clearInterval(disconnectTimer);clearInterval(leaseTimer);
    if(!isDisplay&&!isPaper&&!readOnly){try{if(ownsLease())channel?.postMessage({type:'cards_paused',source_signature:sourceSignature,config_signature:configSignature,controller_id:controllerId});const lease=JSON.parse(localStorage.getItem(leaseKey)||'null');if(lease?.id===controllerId)localStorage.removeItem(leaseKey);}catch(_){}}
    channel?.close();
  });
  window.StudyCards={snapshot:()=>state?copy(state):null,publicState:()=>ready&&!isDisplay&&!isPaper?copy(publicState()):null,dispatch,exportData,validationErrors:()=>[...validationErrors],isReadOnly:()=>readOnly};
})();
