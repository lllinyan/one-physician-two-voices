(function () {
  'use strict';
  // ZIP 2.0, stored entries, UTF-8 names; no compression, ZIP64, or network code.
  // The complete archive and each entry must be smaller than 0xffffffff bytes.
  var LIMIT = 0xffffffff;
  var encoder = new TextEncoder();
  var decoder = new TextDecoder('utf-8', { fatal: true });
  var crcTable = new Uint32Array(256);
  for (var n = 0; n < 256; n++) {
    var value = n;
    for (var bit = 0; bit < 8; bit++) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    crcTable[n] = value >>> 0;
  }
  function crc32(bytes) {
    var crc = 0xffffffff;
    for (var i = 0; i < bytes.length; i++) crc = (crc >>> 8) ^ crcTable[(crc ^ bytes[i]) & 255];
    return (crc ^ 0xffffffff) >>> 0;
  }
  function filename(name) {
    if (typeof name !== 'string' || !name || /[\\:\u0000-\u001f\u007f]/.test(name) || name.charAt(0) === '/' || name.split('/').some(function (part) { return !part || part === '.' || part === '..'; })) throw new Error('ZIP 文件名无效。');
    var bytes = encoder.encode(name);
    if (bytes.length > 65535 || decoder.decode(bytes) !== name) throw new Error('ZIP 文件名过长或包含无效字符。');
    return bytes;
  }
  function input(file) {
    if (!file || typeof file !== 'object') throw new Error('ZIP 条目无效。');
    var name = filename(file.name), data = file.data;
    if (typeof data === 'string') data = encoder.encode(data);
    if (!(data instanceof Uint8Array) && !(data instanceof Blob)) throw new Error('ZIP 只接受文字、Uint8Array 或 Blob。');
    var size = data instanceof Blob ? data.size : data.byteLength;
    if (!Number.isSafeInteger(size) || size < 0 || size >= LIMIT) throw new Error('ZIP 条目超过非 ZIP64 大小限制。');
    return { name: name, data: data, size: size };
  }
  function header(length) {
    var bytes = new Uint8Array(length);
    return { bytes: bytes, view: new DataView(bytes.buffer) };
  }
  async function create(files) {
    if (!Array.isArray(files) || files.length >= 65535) throw new Error('ZIP 最多支持 65534 个文件。');
    var names = new Set(), entries = files.map(function (file) {
      var entry = input(file);
      if (names.has(file.name)) throw new Error('ZIP 文件名重复。');
      names.add(file.name);
      return entry;
    });
    var expectedSize = entries.reduce(function (total, entry) { return total + 76 + 2 * entry.name.length + entry.size; }, 22);
    if (!Number.isSafeInteger(expectedSize) || expectedSize >= LIMIT) throw new Error('ZIP 总大小超过非 ZIP64 限制。');
    var localParts = [], centralParts = [], offset = 0, centralSize = 0;
    for (var i = 0; i < entries.length; i++) {
      var entry = entries[i];
      var data = entry.data instanceof Blob ? new Uint8Array(await entry.data.arrayBuffer()) : entry.data;
      if (data.byteLength !== entry.size) throw new Error('ZIP 条目大小在生成时发生变化。');
      var crc = crc32(data), local = header(30), lv = local.view;
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true); lv.setUint16(6, 0x0800, true);
      lv.setUint16(8, 0, true); lv.setUint16(10, 0, true); lv.setUint16(12, 0x0021, true);
      lv.setUint32(14, crc, true); lv.setUint32(18, data.byteLength, true); lv.setUint32(22, data.byteLength, true);
      lv.setUint16(26, entry.name.length, true); lv.setUint16(28, 0, true);
      var central = header(46), cv = central.view;
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x0800, true);
      cv.setUint16(10, 0, true); cv.setUint16(12, 0, true); cv.setUint16(14, 0x0021, true);
      cv.setUint32(16, crc, true); cv.setUint32(20, data.byteLength, true); cv.setUint32(24, data.byteLength, true);
      cv.setUint16(28, entry.name.length, true); cv.setUint32(42, offset, true);
      localParts.push(local.bytes, entry.name, data);
      centralParts.push(central.bytes, entry.name);
      offset += 30 + entry.name.length + data.byteLength;
      centralSize += 46 + entry.name.length;
    }
    var end = header(22), ev = end.view;
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(8, entries.length, true); ev.setUint16(10, entries.length, true);
    ev.setUint32(12, centralSize, true); ev.setUint32(16, offset, true);
    return new Blob(localParts.concat(centralParts, [end.bytes]), { type: 'application/zip' });
  }
  window.StudyZip = { create: create };
})();
